<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('asistentes_academicos', function (Blueprint $table) {
            $table->string('nombre_remitente', 150)->nullable()->after('email')
                ->comment('Nombre formal para usar como remitente en correos oficiales');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('asistentes_academicos', function (Blueprint $table) {
            $table->dropColumn('nombre_remitente');
        });
    }
};
