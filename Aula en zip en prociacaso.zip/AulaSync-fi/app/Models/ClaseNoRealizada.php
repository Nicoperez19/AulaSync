<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\BelongsToTenant;

class ClaseNoRealizada extends Model
{
    use HasFactory, BelongsToTenant;
    
    protected $connection = 'tenant';

    protected $table = 'clases_no_realizadas';

    protected $fillable = [
        'id_asignatura',
        'id_espacio',
        'id_modulo',
        'run_profesor',
        'fecha_clase',
        'periodo',
        'motivo',
        'observaciones',
        'estado',
        'hora_deteccion',
    ];

    protected $casts = [
        'fecha_clase' => 'date',
        'hora_deteccion' => 'datetime',
    ];

    // Relaciones
    public function asignatura()
    {
        return $this->belongsTo(Asignatura::class, 'id_asignatura', 'id_asignatura');
    }

    public function espacio()
    {
        return $this->belongsTo(Espacio::class, 'id_espacio', 'id_espacio');
    }

    public function profesor()
    {
        return $this->belongsTo(Profesor::class, 'run_profesor', 'run_profesor');
    }

    public function modulo()
    {
        return $this->belongsTo(Modulo::class, 'id_modulo', 'id_modulo');
    }

    // Scopes
    public function scopePorProfesor($query, $runProfesor)
    {
        return $query->where('run_profesor', $runProfesor);
    }

    public function scopePorPeriodo($query, $periodo)
    {
        return $query->where('periodo', $periodo);
    }

    public function scopePorFecha($query, $fechaInicio, $fechaFin = null)
    {
        if ($fechaFin) {
            return $query->whereBetween('fecha_clase', [$fechaInicio, $fechaFin]);
        }

        return $query->whereDate('fecha_clase', $fechaInicio);
    }

    public function scopeNoRealizadas($query)
    {
        return $query->where('estado', 'no_realizada');
    }

    // Métodos estáticos
    public static function registrarClaseNoRealizada($datosClase)
    {
        // Verificar si la fecha es un día feriado o sin actividades
        if (\App\Models\DiaFeriado::esFeriado($datosClase['fecha_clase'])) {
            // Si es feriado, registrar como justificado automáticamente
            $registroExistente = static::where('id_asignatura', $datosClase['id_asignatura'])
                ->where('id_espacio', $datosClase['id_espacio'])
                ->where('id_modulo', $datosClase['id_modulo'])
                ->where('fecha_clase', $datosClase['fecha_clase'])
                ->where('run_profesor', $datosClase['run_profesor'])
                ->first();

            if (! $registroExistente) {
                $feriado = \App\Models\DiaFeriado::obtenerFeriadoEnFecha($datosClase['fecha_clase']);

                return static::create([
                    'id_asignatura' => $datosClase['id_asignatura'],
                    'id_espacio' => $datosClase['id_espacio'],
                    'id_modulo' => $datosClase['id_modulo'],
                    'fecha_clase' => $datosClase['fecha_clase'],
                    'run_profesor' => $datosClase['run_profesor'],
                    'periodo' => $datosClase['periodo'],
                    'motivo' => $feriado ? $feriado->nombre : 'Día sin actividades',
                    'observaciones' => 'Justificado automáticamente - '.($feriado ? ($feriado->descripcion ?? 'Sin descripción') : 'Periodo sin actividad universitaria'),
                    'estado' => 'justificado',
                    'hora_deteccion' => Carbon::now(),
                ]);
            }

            return $registroExistente;
        }

        // Verificar si ya existe un registro para esta clase HOY
        $registroExistente = static::where('id_asignatura', $datosClase['id_asignatura'])
            ->where('id_espacio', $datosClase['id_espacio'])
            ->where('id_modulo', $datosClase['id_modulo'])
            ->where('fecha_clase', $datosClase['fecha_clase'])
            ->where('run_profesor', $datosClase['run_profesor'])
            ->first();

        // Si ya existe, no crear duplicado
        if ($registroExistente) {
            return $registroExistente;
        }

        // Antes de crear, verificar si es un espacio externo o si ya tiene lista de asistencia o reserva en sala paralela/co-docente
        $esRetiroAnticipado = str_contains(strtolower($datosClase['motivo'] ?? ''), 'retiro anticipado');
        $ignorarEntrada = $datosClase['ignorar_entrada'] ?? false;

        if (!empty($datosClase['id_espacio'])) {
            $espacioModel = \App\Models\Espacio::where('id_espacio', $datosClase['id_espacio'])->first();
            if ($espacioModel && method_exists($espacioModel, 'esEspacioExterno') && $espacioModel->esEspacioExterno()) {
                return null;
            }
        }

        if (!$esRetiroAnticipado && !$ignorarEntrada) {
            $runBuscado = $datosClase['run_profesor'] ?? null;
            $idAsigBuscada = $datosClase['id_asignatura'] ?? null;

            // Recopilar RUNs válidos (docente titular y colaboradores de la misma asignatura)
            $runsValidos = $runBuscado ? [$runBuscado] : [];
            if ($idAsigBuscada) {
                $asigObj = \App\Models\Asignatura::where('id_asignatura', $idAsigBuscada)->first();
                if ($asigObj && $asigObj->run_profesor) {
                    $runsValidos[] = $asigObj->run_profesor;
                }
                if ($asigObj && $asigObj->run_profesor_reemplazo) {
                    $runsValidos[] = $asigObj->run_profesor_reemplazo;
                }
                $colabsRuns = \App\Models\ProfesorColaborador::where('id_asignatura', $idAsigBuscada)
                    ->pluck('run_profesor_colaborador')
                    ->filter()
                    ->all();
                $runsValidos = array_values(array_unique(array_merge($runsValidos, $colabsRuns)));
            }

            // 1. Verificar entrada en el mismo espacio o en sala paralela/alternativa para la misma asignatura/docente
            $tuvoEntrada = \App\Models\Reserva::where('fecha_reserva', $datosClase['fecha_clase'])
                ->whereNotNull('hora')
                ->where(function ($q) use ($datosClase, $runsValidos, $idAsigBuscada) {
                    // En el mismo espacio por cualquiera de los docentes de la asignatura
                    $q->where(function ($sub) use ($datosClase, $runsValidos) {
                        $sub->where('id_espacio', $datosClase['id_espacio']);
                        if (!empty($runsValidos)) {
                            $sub->where(function ($rq) use ($runsValidos) {
                                $rq->whereIn('run_profesor', $runsValidos)
                                   ->orWhereIn('run_solicitante', $runsValidos);
                            });
                        } else {
                            $sub->whereNotNull('run_profesor');
                        }
                    });

                    // O en otro espacio (ej. sala paralela 215/212 o laboratorio alternativo) para la misma asignatura
                    if ($idAsigBuscada && !empty($runsValidos)) {
                        $q->orWhere(function ($alt) use ($idAsigBuscada, $runsValidos) {
                            $alt->where('id_asignatura', $idAsigBuscada)
                                ->where(function ($rq) use ($runsValidos) {
                                    $rq->whereIn('run_profesor', $runsValidos)
                                       ->orWhereIn('run_solicitante', $runsValidos);
                                });
                        });
                    }
                })
                ->exists();

            if ($tuvoEntrada) {
                return null;
            }

            // 2. Verificar si existe respaldo de lista de asistencia en el Portal Docente
            try {
                if (\Illuminate\Support\Facades\Schema::connection('tenant')->hasTable('sesiones_asistencia')) {
                    $tieneSesionAsistencia = \App\Models\SesionAsistencia::whereDate('fecha', $datosClase['fecha_clase'])
                        ->where(function ($sq) use ($idAsigBuscada, $runsValidos) {
                            if ($idAsigBuscada) {
                                $sq->where('id_asignatura', $idAsigBuscada);
                            } elseif (!empty($runsValidos)) {
                                $sq->whereIn('run_profesor', $runsValidos);
                            }
                        })
                        ->exists();

                    if ($tieneSesionAsistencia) {
                        return null;
                    }
                }
            } catch (\Throwable $e) {
                // Ignorar si no está disponible la tabla
            }
        }

        // Crear el nuevo registro
        return static::create([
            'id_asignatura' => $datosClase['id_asignatura'],
            'id_espacio' => $datosClase['id_espacio'],
            'id_modulo' => $datosClase['id_modulo'],
            'fecha_clase' => $datosClase['fecha_clase'],
            'run_profesor' => $datosClase['run_profesor'],
            'periodo' => $datosClase['periodo'],
            'motivo' => $datosClase['motivo'] ?? 'No se registró ingreso en el primer módulo',
            'observaciones' => $datosClase['observaciones'] ?? null,
            'estado' => 'no_realizada',
            'hora_deteccion' => Carbon::now(),
        ]);
    }

    /**
     * Limpiar registros incorrectos cuando un profesor registra entrada tarde
     * Se llama cuando se crea una reserva de profesor
     * Ahora mueve los registros a profesor_atrasos en lugar de marcar como justificado
     * 
     * Elimina TODOS los registros de clases_no_realizadas para esa clase/fecha/espacio
     * porque si el profesor llegó (aunque tarde), la clase SÍ se realizó.
     */
    public static function limpiarRegistrosIncorrectos($idEspacio, $fechaReserva, $horaEntrada = null, $runProfesor = null)
    {
        // Buscar registros de hoy para este espacio o salas paralelas del mismo docente en esa fecha.
        $query = static::where('fecha_clase', $fechaReserva);

        if ($runProfesor) {
            $runLimpio = preg_replace('/[^0-9kK]/', '', $runProfesor);
            $query->where(function($q) use ($runProfesor, $runLimpio) {
                $q->where('run_profesor', $runProfesor)
                  ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor, '.', ''), '-', ''), ' ', '') = ?", [$runLimpio]);
            });
        } else {
            $query->where('id_espacio', $idEspacio);
        }

        $registros = $query->get();

        $contadorMovidos = 0;

        foreach ($registros as $registro) {
            // Solo mover a atrasos si era un registro de "no_realizada" o "justificado" con autocorregido
            $debeRegistrarAtraso = $registro->estado === 'no_realizada' || 
                ($registro->estado === 'justificado' && str_contains($registro->observaciones ?? '', 'Auto-corregido'));

            if ($debeRegistrarAtraso) {
                // Intentar obtener la planificación correspondiente
                $planificacion = \App\Models\Planificacion_Asignatura::where('id_asignatura', $registro->id_asignatura)
                    ->where('id_espacio', $registro->id_espacio)
                    ->where('id_modulo', $registro->id_modulo)
                    ->first();

                // Calcular minutos de atraso si tenemos hora de entrada
                $minutosAtraso = 0;
                $horaProgramada = null;
                $esRealmenteAtraso = false;
                
                if ($horaEntrada && $registro->modulo) {
                    $horaProgramada = $registro->modulo->hora_inicio;
                    if ($horaProgramada) {
                        $horaLlegadaCarbon = Carbon::parse($horaEntrada);
                        $horaProgramadaCarbon = Carbon::parse($horaProgramada);
                        
                        // Solo es atraso si llegó DESPUÉS de la hora programada
                        if ($horaLlegadaCarbon->gt($horaProgramadaCarbon)) {
                            $minutosAtraso = $horaProgramadaCarbon->diffInMinutes($horaLlegadaCarbon);
                            $esRealmenteAtraso = true;
                        }
                        // Si llegó antes o a tiempo, NO es atraso
                    }
                }

                // Solo registrar en profesor_atrasos si realmente llegó tarde
                if ($esRealmenteAtraso) {
                    // Verificar que no exista ya un registro de atraso para esta combinación
                    $existeAtraso = \Illuminate\Support\Facades\DB::connection('tenant')->table('profesor_atrasos')
                        ->where('id_asignatura', $registro->id_asignatura)
                        ->where('id_espacio', $registro->id_espacio)
                        ->where('id_modulo', $registro->id_modulo)
                        ->where('fecha', $registro->fecha_clase)
                        ->exists();

                    if (!$existeAtraso) {
                        try {
                            \Illuminate\Support\Facades\DB::connection('tenant')->table('profesor_atrasos')->insert([
                                'id_planificacion' => $planificacion ? $planificacion->id : 0,
                                'id_asignatura' => $registro->id_asignatura,
                                'id_espacio' => $registro->id_espacio,
                                'id_modulo' => $registro->id_modulo,
                                'run_profesor' => $runProfesor ?? $registro->run_profesor,
                                'fecha' => $registro->fecha_clase,
                                'hora_programada' => $horaProgramada,
                                'hora_llegada' => $horaEntrada,
                                'minutos_atraso' => $minutosAtraso,
                                'periodo' => $registro->periodo,
                                'observaciones' => 'Profesor llegó tarde pero realizó la clase',
                                'justificado' => false,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                            $contadorMovidos++;
                        } catch (\Exception $e) {
                            \Illuminate\Support\Facades\Log::warning("No se pudo crear registro de atraso: " . $e->getMessage());
                        }
                    }
                }
            }

            // Actualizar el registro a estado 'realizada' (porque la clase SÍ se realizó)
            try {
                $registro->update([
                    'estado' => 'realizada',
                    'motivo' => ($minutosAtraso ?? 0) > 0 ? "Clase realizada con atraso de {$minutosAtraso} min" : "Clase realizada",
                    'observaciones' => "Profesor registró ingreso a las " . ($horaEntrada ?? now()->format('H:i:s')),
                ]);
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::warning("No se pudo actualizar registro a realizada: " . $e->getMessage());
            }
        }

        return $contadorMovidos;
    }

    public static function obtenerEstadisticasPorProfesor($periodo = null, $fechaInicio = null, $fechaFin = null)
    {
        $query = static::with(['asignatura', 'profesor'])
            ->selectRaw('run_profesor, COUNT(*) as total_ausencias')
            ->groupBy('run_profesor');

        if ($periodo) {
            $query->where('periodo', $periodo);
        }

        if ($fechaInicio && $fechaFin) {
            $query->whereBetween('fecha_clase', [$fechaInicio, $fechaFin]);
        } elseif ($fechaInicio) {
            $query->whereDate('fecha_clase', '>=', $fechaInicio);
        }

        return $query->get();
    }
}
