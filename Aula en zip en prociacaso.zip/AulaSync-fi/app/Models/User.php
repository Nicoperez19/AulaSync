<?php

namespace App\Models;

use App\Mail\ResetPasswordMail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Mail;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, HasRoles, Notifiable;

    /**
     * Force connection to central database (mysql)
     * This ensures User model always queries the central database,
     * even when accessed from tenant-connected models
     */
    protected $connection = 'mysql';

    protected $primaryKey = 'run';

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'run',
        'name',
        'email',
        'password',
        'celular',
        'direccion',
        'fecha_nacimiento',
        'id_universidad',
        'id_facultad',
        'id_carrera',
        'id_area_academica',
        'id_sede',
        'is_superuser',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'run' => 'string',
        'fecha_nacimiento' => 'date',
        'is_superuser' => 'boolean',
    ];

    /**
     * Get the name of the unique identifier for the user.
     *
     * @return string
     */
    public function getAuthIdentifierName()
    {
        return 'run';
    }

    public function universidad()
    {
        return $this->belongsTo(Universidad::class, 'id_universidad');
    }

    public function facultad()
    {
        return $this->belongsTo(Facultad::class, 'id_facultad');
    }

    public function carrera()
    {
        return $this->belongsTo(Carrera::class, 'id_carrera');
    }

    public function areaAcademica()
    {
        return $this->belongsTo(AreaAcademica::class, 'id_area_academica');
    }

    public function sede()
    {
        return $this->belongsTo(Sede::class, 'id_sede');
    }

    public function profesor()
    {
        return $this->hasOne(Profesor::class, 'run_profesor', 'run');
    }

    public function notificaciones()
    {
        return $this->hasMany(Notificacion::class, 'run_usuario', 'run');
    }

    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        Mail::to($this->email)->send(new ResetPasswordMail($token, $this->email));
    }

    /**
     * Determina si el usuario actual tiene privilegios de superadministrador.
     */
    public function isSuperAdmin(): bool
    {
        return (bool) (
            $this->is_superuser ||
            (string) $this->run === '19716146' ||
            (method_exists($this, 'hasRole') && $this->hasRole('Super Admin'))
        );
    }
}

