<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use App\Traits\RedirectByRole;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    use RedirectByRole;

    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        // Verificar si hay una URL guardada por expiración de sesión
        $intendedUrl = $request->session()->get('url.intended');
        
        if ($intendedUrl) {
            // Limpiar la URL guardada
            $request->session()->forget('url.intended');
            return redirect($intendedUrl);
        }

        // Verificar si hay una URL enviada desde el formulario (localStorage)
        $formIntendedUrl = $request->input('intended_url');
        if ($formIntendedUrl && filter_var($formIntendedUrl, FILTER_VALIDATE_URL)) {
            return redirect($formIntendedUrl);
        }

        // Obtener el usuario autenticado
        $user = Auth::user();

        // DEBUG: Log de valores del usuario para diagnosticar redirección
        Log::info('🔐 Login - Datos del usuario', [
            'run' => $user->run,
            'name' => $user->name,
            'is_superuser' => $user->is_superuser,
            'is_superuser_type' => gettype($user->is_superuser),
            'id_sede' => $user->id_sede,
            'id_sede_type' => gettype($user->id_sede),
        ]);

        // Si el usuario es Control Docente, inicializar tenant antes de redirigir a Plano Digital
        if ($user->hasRole('Control Docente')) {
            Log::info('✅ Control Docente detectado, inicializando tenant y redirigiendo a Plano Digital', [
                'run' => $user->run,
                'id_sede' => $user->id_sede,
            ]);

            if ($user->id_sede) {
                return redirect()->route('sedes.redirect', ['sede' => $user->id_sede]);
            }

            // Sin sede asignada: error de configuración
            Log::warning('❌ Control Docente sin sede asignada', ['run' => $user->run]);
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return redirect()->route('login')->with('error', 'Tu cuenta no tiene una sede asignada. Por favor, contacta al administrador del sistema.');
        }

        // Si el usuario es Profesor (y no es superusuario ni administrador/supervisor/director)
        if ($user->hasRole('Profesor') && !$user->hasAnyRole(['Administrador', 'Supervisor', 'Director', 'Super Admin']) && !$user->is_superuser && (string)$user->run !== '19716146') {
            Log::info('✅ Profesor detectado, activando sede y redirigiendo al portal docente', [
                'run' => $user->run,
                'id_sede' => $user->id_sede,
            ]);

            if (!$user->id_sede) {
                Log::warning('❌ Profesor sin sede asignada', ['run' => $user->run]);
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return redirect()->route('login')->with('error', 'Tu cuenta de docente no tiene una sede asignada. Por favor, contacta al administrador del sistema.');
            }

            $tenantService = app(\App\Services\TenantSessionService::class);
            $sede = $tenantService->activarPorIdSede($user->id_sede);

            if (!$sede) {
                Log::warning('❌ Sede del profesor no disponible o inactiva', [
                    'run' => $user->run,
                    'id_sede' => $user->id_sede,
                ]);
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return redirect()->route('login')->with('error', 'La sede asignada a tu cuenta no está disponible actualmente.');
            }

            if ($sede->tenant && $sede->tenant->needsInitialization()) {
                Log::warning('⚠️ Sede del profesor no inicializada', [
                    'run' => $user->run,
                    'id_sede' => $user->id_sede,
                ]);
                return redirect()->route('docente.sede-no-inicializada');
            }

            return redirect()->route('docente.dashboard');
        }

        // Si el usuario es Director con sede asignada, redirigir directamente
        if ($user->hasRole('Director') && $user->id_sede) {
            Log::info('✅ Director con sede asignada detectado, redirigiendo automáticamente', [
                'run' => $user->run,
                'id_sede' => $user->id_sede,
            ]);
            return redirect()->route('sedes.redirect', ['sede' => $user->id_sede]);
        }

        // Si el usuario es superusuario, administrador, supervisor, director o usuario maestro (19716146), mostrar selección de sedes
        if ($user->is_superuser || $user->hasRole('Administrador') || $user->hasRole('Supervisor') || $user->hasRole('Director') || $user->hasRole('Super Admin') || (string)$user->run === '19716146') {
            Log::info('✅ Superusuario / Administrador Maestro detectado, mostrando selección de sedes', [
                'run' => $user->run,
            ]);
            
            return redirect()->route('sedes.selection');
        }

        // Si el usuario NO es superusuario pero tiene una sede asignada
        if ($user->id_sede) {
            Log::info('✅ Usuario con sede asignada, redirigiendo automáticamente', [
                'run' => $user->run,
                'id_sede' => $user->id_sede,
            ]);
            
            // Redirigir directamente a la sede asignada
            return redirect()->route('sedes.redirect', ['sede' => $user->id_sede]);
        }

        // Usuario NO es superusuario Y NO tiene sede asignada
        // Esto es un error de configuración - debe contactar al administrador
        Log::warning('❌ Usuario sin sede asignada y sin permisos de superusuario', [
            'run' => $user->run,
        ]);

        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect()->route('login')->with('error', 'Tu cuenta no tiene una sede asignada. Por favor, contacta al administrador del sistema.');
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->forget(['tenant_id', 'tenant', 'url.intended']);
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        if (app()->bound('tenant')) {
            app()->forgetInstance('tenant');
        }

        return redirect()->route('login');
    }
}
