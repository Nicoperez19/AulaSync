<?php

namespace App\Http\Controllers;

use App\Models\Profesor;
use App\Models\Universidad;
use App\Models\Facultad;
use App\Models\Carrera;
use App\Models\Reserva;
use App\Models\Asignatura;
use App\Models\AreaAcademica;
use App\Models\Tenant;
use Illuminate\Http\Request;
use App\Models\Espacio;
use App\Traits\RunNormalizer;
use App\Helpers\SemesterHelper;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;

class ProfesorController extends Controller
{
    use RunNormalizer;

    /**
     * Crear reserva para profesor
     */
    public function index()
    {
        try {
            $universidades = Universidad::all();
            $facultades = Facultad::with('sede.universidad')->get();
            $carreras = Carrera::with('areaAcademica.facultad.sede.universidad')->get();
            $areasAcademicas = AreaAcademica::with('facultad.sede.universidad')->get();

            return view('profesores.index', compact('universidades', 'facultades', 'carreras', 'areasAcademicas'));
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Hubo un problema al cargar los profesores.'])->withInput();
        }
    }
    /**
     * Crear reserva para profesor
     */
    public function crearReservaProfesor(Request $request)
    {
        try {
            // Establecer contexto del tenant desde el request
            $this->establecerContextoTenant();

            $request->validate([
                'run_profesor' => 'required',
                'id_espacio' => 'required|string'
            ]);

            $runProfesor = $this->normalizeRun($request->input('run_profesor'));
            $idEspacio = $request->input('id_espacio');

            // Normalizar el ID del espacio usando la lógica del tenant actual
            if (!empty($idEspacio)) {
                $idEspacio = strtoupper(trim(str_replace(' ', '', $idEspacio)));
                $tenant = Tenant::current() ?? Tenant::find(tenant_id());
                if ($tenant) {
                    $prefix = strtoupper($tenant->prefijo_espacios ?: $tenant->domain);
                    $normalizedInput = str_replace('-', '', $idEspacio);
                    if (strpos($normalizedInput, $prefix) === 0) {
                        $normalizedInput = substr($normalizedInput, strlen($prefix));
                    }
                    $idEspacio = $prefix . '-' . $normalizedInput;
                }
            }

            // Verificar que el espacio existe
            $espacio = Espacio::where('id_espacio', $idEspacio)->first();
            if (!$espacio) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Espacio no encontrado'
                ], 404);
            }

            // Verificar que el espacio esté disponible
            if ($espacio->estado !== 'Disponible') {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'El espacio no está disponible'
                ], 400);
            }

            $horaActual = now()->format('H:i:s');
            $fechaActual = now()->format('Y-m-d');

            // Validar horario académico
            $hora = (int)now()->format('H');
            $minutos = (int)now()->format('i');
            $horaEnMinutos = $hora * 60 + $minutos;

            $inicioAcademico = 7 * 60 + 30; // 07:30 (pero el mensaje dirá 08:10)
            $finAcademico = 23 * 60; // 23:00

            if ($horaEnMinutos < $inicioAcademico || $horaEnMinutos >= $finAcademico) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'No se pueden crear reservas fuera del horario académico (08:10 - 23:00).'
                ], 400);
            }

            // Verificar si el profesor existe
            $profesor = Profesor::where('run_profesor', $runProfesor)->first();
            if (!$profesor) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Profesor no encontrado'
                ], 404);
            }

            // Verificar si ya tiene una reserva activa
            $reservaExistente = Reserva::where('run_profesor', $runProfesor)
                ->where('estado', 'activa')
                ->whereNull('hora_salida')
                ->first();

            if ($reservaExistente) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Ya tienes una reserva activa en otro espacio'
                ], 400);
            }

            // Encontrar el módulo actual para asignar como inicio/fin
            $diaSemanaStr = strtolower(\Carbon\Carbon::parse($fechaActual)->locale('es')->isoFormat('dddd'));
            $diaNormalizado = \App\Helpers\ModulosHelper::normalizarDia($diaSemanaStr);
            $moduloActual = \App\Helpers\ModulosHelper::obtenerModuloActual($horaActual, $diaNormalizado);
            $horarios = \App\Helpers\ModulosHelper::getHorariosModulos()[$diaNormalizado] ?? [];

            // Crear la reserva espontánea (sin vincular a una asignatura programada)
            $reserva = new Reserva();
            $reserva->id_reserva = Reserva::generarIdUnico();
            $reserva->run_profesor = $runProfesor;
            $reserva->id_espacio = $espacio->id_espacio;
            $reserva->id_asignatura = null;
            $reserva->fecha_reserva = $fechaActual;
            $reserva->hora = $horaActual;
            
            if ($moduloActual) {
                $reserva->modulo_inicio = $moduloActual;
                $reserva->modulo_fin = $moduloActual;
                $reserva->hora_salida = $horarios[$moduloActual]['fin'];
                $reserva->modulos = 1;
            } else {
                $reserva->hora_salida = \Carbon\Carbon::parse($horaActual)->addHour()->format('H:i:s');
            }
            
            $reserva->estado = 'activa';
            $reserva->tipo_reserva = 'espontanea';
            $reserva->save();

            // Cambiar estado del espacio
            $espacio->estado = 'Ocupado';
            $espacio->save();

            // Limpiar registros incorrectos de clases no realizadas (mover a atrasos)
            \App\Models\ClaseNoRealizada::limpiarRegistrosIncorrectos(
                $espacio->id_espacio,
                $fechaActual,
                $horaActual,
                $profesor->run_profesor
            );

            // Enviar comprobante de reserva por correo
            app(\App\Services\ReservaService::class)->enviarCorreoReserva($reserva, $profesor->email ?? null);

            return response()->json([
                'success' => true,
                'mensaje' => 'Reserva creada exitosamente para el profesor',
                'reserva' => [
                    'id' => $reserva->id_reserva,
                    'profesor' => $profesor->name,
                    'run_profesor' => $profesor->run_profesor,
                    'espacio' => $espacio->nombre_espacio,
                    'fecha' => $fechaActual,
                    'hora_inicio' => $horaActual
                ]
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::error('Error de validación al crear reserva de profesor: ' . json_encode($e->errors()));
            return response()->json([
                'success' => false,
                'mensaje' => 'Error de validación en los datos enviados',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error al crear reserva de profesor: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'mensaje' => 'Error al crear reserva: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Crear reserva automáticamente para profesor con clase programada
     * Usa directamente los módulos de la programación del profesor
     */
    public function crearReservaProfesorAutomatica(Request $request)
    {
        try {
            $this->establecerContextoTenant();

            $request->validate([
                'run_profesor' => 'required',
                'id_espacio' => 'required|string'
            ]);

            $runProfesor = $this->normalizeRun($request->input('run_profesor'));
            $idEspacio = $request->input('id_espacio');

            // Normalizar el ID del espacio usando la lógica del tenant actual
            if (!empty($idEspacio)) {
                $idEspacio = strtoupper(trim(str_replace(' ', '', $idEspacio)));
                $tenant = Tenant::current() ?? Tenant::find(tenant_id());
                if ($tenant) {
                    $prefix = strtoupper($tenant->prefijo_espacios ?: $tenant->domain);
                    $normalizedInput = str_replace('-', '', $idEspacio);
                    if (strpos($normalizedInput, $prefix) === 0) {
                        $normalizedInput = substr($normalizedInput, strlen($prefix));
                    }
                    $idEspacio = $prefix . '-' . $normalizedInput;
                }
            }

            $horaActual = now()->format('H:i:s');
            $fechaActual = now()->format('Y-m-d');

            // Normalizar el RUN para búsqueda (preservando K/k)
            $runLimpio = strtoupper(preg_replace('/[^0-9Kk]/', '', $runProfesor));
            $runSinDv = strlen($runLimpio) > 1 ? substr($runLimpio, 0, -1) : $runLimpio;

            // Verificar que el espacio existe
            $espacio = Espacio::where('id_espacio', $idEspacio)->first();
            if (!$espacio) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Espacio no encontrado'
                ], 404);
            }

            // Verificar que el espacio esté disponible
            if ($espacio->estado !== 'Disponible') {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'El espacio no está disponible'
                ], 400);
            }

            // Validar horario académico
            $hora = (int)now()->format('H');
            $minutos = (int)now()->format('i');
            $horaEnMinutos = $hora * 60 + $minutos;

            $inicioAcademico = 7 * 60 + 30; // 07:30 (pero el mensaje dirá 08:10)
            $finAcademico = 23 * 60; // 23:00

            if ($horaEnMinutos < $inicioAcademico || $horaEnMinutos >= $finAcademico) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'No se pueden crear reservas fuera del horario académico (08:10 - 23:00).'
                ], 400);
            }

            // Verificar si el profesor existe
            $profesor = Profesor::where('run_profesor', $runProfesor)
                ->orWhere('run_profesor', $runLimpio)
                ->orWhere('run_profesor', $runSinDv)
                ->first();
            
            if (!$profesor) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Profesor no encontrado'
                ], 404);
            }

            // Verificar si ya tiene una reserva activa
            $reservaExistente = Reserva::where('run_profesor', $profesor->run_profesor)
                ->where('estado', 'activa')
                ->whereNull('hora_salida')
                ->first();

            // Si tiene una reserva activa en otro espacio cuya hora de término ya pasó, auto-finalizarla
            if ($reservaExistente && $reservaExistente->id_espacio != $espacio->id_espacio) {
                if ($reservaExistente->hora_salida && $reservaExistente->hora_salida < now()->format('H:i:s')) {
                    $reservaExistente->estado = 'finalizada';
                    $reservaExistente->observaciones = ($reservaExistente->observaciones ?? '') . ' | Auto-finalizada al iniciar clase en ' . $espacio->nombre_espacio;
                    $reservaExistente->save();
                    $reservaExistente = null;
                } else {
                    return response()->json([
                        'success' => false,
                        'mensaje' => 'Ya tienes una reserva activa en otro espacio'
                    ], 400);
                }
            }

            // Obtener la programación del profesor para este espacio (usando Eloquent para respetar la conexión 'tenant')
            $diaActual = strtolower(now()->locale('es')->isoFormat('dddd'));
            $diaNormalizado = \App\Helpers\ModulosHelper::normalizarDia($diaActual);
            $diasPosibles = array_unique([$diaActual, $diaNormalizado, 'lunes', 'martes', 'miércoles', 'miercoles', 'jueves', 'viernes', 'sábado', 'sabado']);
            $horaConAnticipacion = now()->copy()->addMinutes(30)->format('H:i:s');
            $espacioLimpio = str_replace(['-', ' '], '', $espacio->id_espacio);

            $programacion = \App\Models\Planificacion_Asignatura::with(['modulo', 'asignatura'])
                ->where(function ($eq) use ($espacio, $espacioLimpio) {
                    $eq->where('id_espacio', $espacio->id_espacio)
                       ->orWhereRaw("REPLACE(REPLACE(id_espacio, '-', ''), ' ', '') = ?", [$espacioLimpio]);
                })
                ->where(function ($qPrincipal) use ($profesor, $runProfesor, $runLimpio, $runSinDv) {
                    $qPrincipal->whereHas('asignatura', function ($q) use ($profesor, $runProfesor, $runLimpio, $runSinDv) {
                        $q->where('run_profesor', $profesor->run_profesor)
                          ->orWhere('run_profesor', $runProfesor)
                          ->orWhere('run_profesor', $runLimpio)
                          ->orWhere('run_profesor', $runSinDv)
                          ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor, '.', ''), '-', ''), ' ', '') = ?", [$runLimpio])
                          ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor, '.', ''), '-', ''), ' ', '') = ?", [$runSinDv]);
                    })->orWhereHas('horario', function ($q) use ($profesor, $runProfesor, $runLimpio, $runSinDv) {
                        $q->where('run_profesor', $profesor->run_profesor)
                          ->orWhere('run_profesor', $runProfesor)
                          ->orWhere('run_profesor', $runLimpio)
                          ->orWhere('run_profesor', $runSinDv)
                          ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor, '.', ''), '-', ''), ' ', '') = ?", [$runLimpio])
                          ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor, '.', ''), '-', ''), ' ', '') = ?", [$runSinDv]);
                    });
                })
                ->whereHas('modulo', function ($q) use ($diasPosibles, $horaActual, $horaConAnticipacion) {
                    $q->whereIn('dia', $diasPosibles)
                      ->where(function ($subQ) use ($horaActual, $horaConAnticipacion) {
                          $subQ->where(function ($sq1) use ($horaActual) {
                              $sq1->where('hora_inicio', '<=', $horaActual)
                                  ->where('hora_termino', '>=', $horaActual);
                          })->orWhere(function ($sq2) use ($horaActual, $horaConAnticipacion) {
                              $sq2->where('hora_inicio', '>', $horaActual)
                                  ->where('hora_inicio', '<=', $horaConAnticipacion);
                          });
                      });
                })
                ->first();

            $esTemporal = false;
            $planColaborador = null;

            if (!$programacion) {
                // Buscar si tiene una clase temporal activa (PlanificacionProfesorColaborador)
                $hoyFecha = $fechaActual;
                $planColaborador = \App\Models\PlanificacionProfesorColaborador::with(['modulo', 'profesorColaborador.asignatura'])
                    ->where(function ($eq) use ($espacio, $espacioLimpio) {
                        $eq->where('id_espacio', $espacio->id_espacio)
                           ->orWhereRaw("REPLACE(REPLACE(id_espacio, '-', ''), ' ', '') = ?", [$espacioLimpio]);
                    })
                    ->whereHas('profesorColaborador', function ($q) use ($profesor, $runProfesor, $runLimpio, $runSinDv, $hoyFecha) {
                        $q->where('estado', 'activo')
                          ->where('fecha_inicio', '<=', $hoyFecha)
                          ->where('fecha_termino', '>=', $hoyFecha)
                          ->where(function ($subQ) use ($profesor, $runProfesor, $runLimpio, $runSinDv) {
                              $subQ->where('run_profesor_colaborador', $profesor->run_profesor)
                                   ->orWhere('run_profesor_colaborador', $runProfesor)
                                   ->orWhere('run_profesor_colaborador', $runLimpio)
                                   ->orWhere('run_profesor_colaborador', $runSinDv)
                                   ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor_colaborador, '.', ''), '-', ''), ' ', '') = ?", [$runLimpio])
                                   ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor_colaborador, '.', ''), '-', ''), ' ', '') = ?", [$runSinDv]);
                          });
                    })
                    ->whereHas('modulo', function ($q) use ($diasPosibles, $horaActual, $horaConAnticipacion) {
                        $q->whereIn('dia', $diasPosibles)
                          ->where(function ($subQ) use ($horaActual, $horaConAnticipacion) {
                              $subQ->where(function ($sq1) use ($horaActual) {
                                  $sq1->where('hora_inicio', '<=', $horaActual)
                                      ->where('hora_termino', '>=', $horaActual);
                              })->orWhere(function ($sq2) use ($horaActual, $horaConAnticipacion) {
                                  $sq2->where('hora_inicio', '>', $horaActual)
                                      ->where('hora_inicio', '<=', $horaConAnticipacion);
                              });
                          });
                    })
                    ->first();

                if ($planColaborador) {
                    $esTemporal = true;
                }
            }

            if (!$programacion && !$planColaborador) {
                // Si no encuentra programación ni regular ni temporal, retornar error
                return response()->json([
                    'success' => false,
                    'mensaje' => 'No se encontró programación para este profesor en este espacio'
                ], 400);
            }

            // Encontrar bloques consecutivos de planificación
            $periodo = \App\Helpers\SemesterHelper::getCurrentPeriod();
            $idAsignatura = null;
            $moduloFinalObj = null;
            $moduloInicioObj = null;
            $nombreAsignaturaResp = '';

            if (!$esTemporal && $programacion) {
                $planificacionesMismoBloque = \App\Models\Planificacion_Asignatura::with('modulo')
                    ->where('id_espacio', $espacio->id_espacio)
                    ->where('id_asignatura', $programacion->id_asignatura)
                    ->where(function ($q) use ($periodo, $programacion) {
                        $q->where('id_horario', $programacion->id_horario)
                          ->orWhereHas('horario', function ($hq) use ($periodo) {
                              $hq->where('periodo', $periodo);
                          });
                    })
                    ->whereHas('modulo', function ($q) use ($diasPosibles) {
                        $q->whereIn('dia', $diasPosibles);
                    })
                    ->get();

                $numModuloActual = \App\Helpers\ModulosHelper::getNumeroModulo($programacion->id_modulo);
                $moduloFin = $numModuloActual;
                
                $modulosAsociados = [];
                foreach ($planificacionesMismoBloque as $planItem) {
                    if ($planItem->modulo) {
                        $num = \App\Helpers\ModulosHelper::getNumeroModulo($planItem->id_modulo);
                        $modulosAsociados[$num] = $planItem->modulo;
                    }
                }
                
                $cantidadModulos = 1;
                while (isset($modulosAsociados[$moduloFin + 1])) {
                    $moduloFin++;
                    $cantidadModulos++;
                }
                
                $moduloFinalObj = $modulosAsociados[$moduloFin] ?? $programacion->modulo;
                $moduloInicioObj = $programacion->modulo;
                $idAsignatura = $programacion->id_asignatura;
                $nombreAsignaturaResp = $programacion->asignatura->nombre_asignatura ?? 'Clase regular';
            } else {
                // Clases temporales (colaborador)
                $idColab = $planColaborador->id_profesor_colaborador;
                $planificacionesMismoBloque = \App\Models\PlanificacionProfesorColaborador::with('modulo')
                    ->where('id_espacio', $espacio->id_espacio)
                    ->where('id_profesor_colaborador', $idColab)
                    ->whereHas('modulo', function ($q) use ($diasPosibles) {
                        $q->whereIn('dia', $diasPosibles);
                    })
                    ->get();

                $numModuloActual = \App\Helpers\ModulosHelper::getNumeroModulo($planColaborador->id_modulo);
                $moduloFin = $numModuloActual;
                
                $modulosAsociados = [];
                foreach ($planificacionesMismoBloque as $planItem) {
                    if ($planItem->modulo) {
                        $num = \App\Helpers\ModulosHelper::getNumeroModulo($planItem->id_modulo);
                        $modulosAsociados[$num] = $planItem->modulo;
                    }
                }
                
                $cantidadModulos = 1;
                while (isset($modulosAsociados[$moduloFin + 1])) {
                    $moduloFin++;
                    $cantidadModulos++;
                }
                
                $moduloFinalObj = $modulosAsociados[$moduloFin] ?? $planColaborador->modulo;
                $moduloInicioObj = $planColaborador->modulo;
                $idAsignatura = $planColaborador->profesorColaborador->id_asignatura ?? null;
                $nombreAsignaturaResp = $planColaborador->profesorColaborador->nombre_asignatura_temporal ?? ($planColaborador->profesorColaborador->asignatura->nombre_asignatura ?? 'Clase temporal');
            }

            // Si el docente ya tenía una reserva programada en este espacio hoy que cubra este horario,
            // la activamos y convertimos a clase oficial en lugar de duplicarla
            $reservaProgramadaExistente = Reserva::where('id_espacio', $espacio->id_espacio)
                ->where('fecha_reserva', $fechaActual)
                ->where('estado', 'programada')
                ->where(function ($q) use ($profesor, $runProfesor, $runLimpio) {
                    $q->where('run_profesor', $profesor->run_profesor)
                      ->orWhere('run_profesor', $runProfesor)
                      ->orWhere('run_profesor', $runLimpio)
                      ->orWhere('run_solicitante', $profesor->run_profesor)
                      ->orWhereRaw("REPLACE(REPLACE(REPLACE(run_profesor, '.', ''), '-', ''), ' ', '') = ?", [$runLimpio]);
                })
                ->first();

            // Crear o actualizar la reserva con la programación encontrada
            $reserva = $reservaProgramadaExistente ?? new Reserva();
            if (!$reservaProgramadaExistente) {
                $reserva->id_reserva = Reserva::generarIdUnico();
            }
            $reserva->run_profesor = $profesor->run_profesor;
            $reserva->id_espacio = $espacio->id_espacio;
            $reserva->id_asignatura = $idAsignatura;
            $reserva->fecha_reserva = $fechaActual;
            // ✓ Hora real del escaneo (no la hora programada del módulo)
            $reserva->hora = now()->format('H:i:s');
            // ✓ Fin del último módulo consecutivo (para auto-finalización correcta)
            $reserva->hora_salida = $moduloFinalObj->hora_termino ?? null;
            $reserva->modulo_inicio = $numModuloActual;
            $reserva->modulo_fin = $moduloFin;
            $reserva->modulos = $cantidadModulos; // Calculado basado en la programación consecuente
            $reserva->estado = 'activa'; // Creada automáticamente pero activa
            $reserva->tipo_reserva = 'clase'; // Marcado como clase programada para registro de asistencia
            $reserva->save();

            // Cambiar estado del espacio
            $espacio->estado = 'Ocupado';
            $espacio->save();

            // Enviar correo de confirmación de uso de sala
            app(\App\Services\ReservaService::class)->enviarCorreoReserva($reserva, $profesor->email ?? null);

            // Limpiar registros incorrectos de clases no realizadas
            \App\Models\ClaseNoRealizada::limpiarRegistrosIncorrectos(
                $espacio->id_espacio,
                $fechaActual,
                $moduloInicioObj->hora_inicio ?? null,
                $profesor->run_profesor
            );

            return response()->json([
                'success' => true,
                'mensaje' => 'Reserva creada automáticamente según programación',
                'reserva' => [
                    'id'          => $reserva->id_reserva,
                    'profesor'    => $profesor->name,
                    'run_profesor'=> $profesor->run_profesor,
                    'espacio'     => $espacio->nombre_espacio,
                    'fecha'       => $fechaActual,
                    'asignatura'  => $nombreAsignaturaResp,
                    'hora_inicio' => $moduloInicioObj->hora_inicio ?? null,
                    'hora_termino'=> $moduloFinalObj->hora_termino ?? null,
                ]
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::error('Error de validación al crear reserva automática: ' . json_encode($e->errors()));
            return response()->json([
                'success' => false,
                'mensaje' => 'Error de validación en los datos enviados',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error al crear reserva automática de profesor: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'mensaje' => 'Error al crear reserva: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'run_profesor' => 'required|integer|digits_between:7,8|unique:profesors,run_profesor',
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255|unique:profesors,email',
                'celular' => 'nullable|string|regex:/^9\d{8}$/',
                'direccion' => 'nullable|string|max:255',
                'fecha_nacimiento' => 'nullable|date',
                'anio_ingreso' => 'nullable|integer|min:1900|max:' . (date('Y') + 1),
                'tipo_profesor' => 'required|in:Profesor Colaborador,Profesor Responsable,Ayudante',
                'id_universidad' => 'nullable|exists:universidades,id_universidad',
                'id_facultad' => 'nullable|exists:facultades,id_facultad',
                'id_carrera' => 'nullable|exists:carreras,id_carrera',
                'id_area_academica' => 'nullable|exists:area_academicas,id_area_academica',
            ]);

            Profesor::create($validatedData);

            return redirect()->route('professors.index')->with('success', 'Profesor creado exitosamente.');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Hubo un problema al crear el profesor. Por favor, intente nuevamente.'])->withInput();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        try {
            $profesor = Profesor::findOrFail($id);
            $universidades = Universidad::all();
            $facultades = Facultad::with('sede.universidad')->get();
            $carreras = Carrera::with('areaAcademica.facultad.sede.universidad')->get();
            $areasAcademicas = AreaAcademica::with('facultad.sede.universidad')->get();
            
            // Cargar clases temporales donde es colaborador
            $clasesTemporales = $profesor->clasesTemporalesColaborador()
                ->with(['asignatura', 'planificaciones.modulo'])
                ->orderBy('fecha_termino', 'desc')
                ->get();

            return view('profesores.edit', compact('profesor', 'universidades', 'facultades', 'carreras', 'areasAcademicas', 'clasesTemporales'));
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return redirect()->route('professors.index')->withErrors(['error' => 'Profesor no encontrado.']);
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Error al cargar el profesor: ' . $e->getMessage()]);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $request->validate([
                'run_profesor' => 'required|string',
                'id_espacio' => 'required|string'
            ]);

            $runProfesor = $request->input('run_profesor');
            $idEspacio = $request->input('id_espacio');

            // Verificar que el espacio existe
            $espacio = Espacio::where('id_espacio', $idEspacio)->first();
            if (!$espacio) {
                return redirect()->route('professors.index')->withErrors(['error' => 'Espacio no encontrado.']);
            }

            // Aquí iría la lógica de actualización del profesor
            return redirect()->route('professors.index')->with('success', 'Profesor actualizado exitosamente.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return redirect()->route('professors.index')->withErrors(['error' => 'Profesor no encontrado.']);
        } catch (\Exception $e) {
            return redirect()->route('professors.index')->withErrors(['error' => 'Error al actualizar el profesor.']);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $profesor = Profesor::findOrFail($id);
            $profesor->delete();
            return redirect()->route('professors.index')->with('success', 'Profesor eliminado exitosamente.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['success' => false, 'message' => 'Profesor no encontrado.'], 404);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Error al borrar el profesor: ' . $e->getMessage()], 500);
        }
    }

    /**
     * API method for getting profesor information (existing method)
     */
    public function getProfesor($run)
    {
        try {
            $profesor = Profesor::where('run_profesor', $run)->first();
            if (!$profesor) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Profesor no encontrado'
                ], 404);
            }

            // Aquí deberías obtener el espacio, por ejemplo por id_espacio (ajusta según tu lógica):
            $espacio = Espacio::where('id_espacio', $profesor->id_espacio ?? null)->first();
            if (!$espacio) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Espacio no encontrado'
                ], 404);
            }

            if ($espacio->estado !== 'Disponible') {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'El espacio no está disponible'
                ], 400);
            }

            $horaActual = now()->format('H:i:s');
            $fechaActual = now()->format('Y-m-d');

            // Validar horario académico
            $hora = (int)now()->format('H');
            $minutos = (int)now()->format('i');
            $horaEnMinutos = $hora * 60 + $minutos;

            $inicioAcademico = 7 * 60 + 30; // 07:30 (pero el mensaje dirá 08:10)
            $finAcademico = 23 * 60; // 23:00

            if ($horaEnMinutos < $inicioAcademico || $horaEnMinutos >= $finAcademico) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'No se pueden crear reservas fuera del horario académico (08:10 - 23:00).'
                ], 400);
            }

            // Verificar si ya tiene una reserva activa
            $reservaExistente = Reserva::where('run_profesor', $run)
                ->where('estado', 'activa')
                ->whereNull('hora_salida')
                ->first();

            if ($reservaExistente) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Ya tienes una reserva activa en otro espacio'
                ], 400);
            }

            // Obtener profesor y su asignatura principal
            $profesor = Profesor::where('run_profesor', $run)->first();
            $asignatura = $profesor ? $profesor->asignaturas()->first() : null;

            // Crear la reserva
            $reserva = new Reserva();
            $reserva->id_reserva = Reserva::generarIdUnico();
            $reserva->run_profesor = $run;
            $reserva->id_espacio = $espacio->id_espacio;
            $reserva->id_asignatura = $asignatura ? $asignatura->id_asignatura : null;
            $reserva->fecha_reserva = $fechaActual;
            $reserva->hora = $horaActual;
            $reserva->estado = 'activa';
            $reserva->save();

            // Cambiar estado del espacio
            $espacio->estado = 'Ocupado';
            $espacio->save();

            // Enviar correo de confirmación de uso de sala
            app(\App\Services\ReservaService::class)->enviarCorreoReserva($reserva, $profesor->email ?? null);

            // Limpiar registros incorrectos de clases no realizadas (mover a atrasos)
            \App\Models\ClaseNoRealizada::limpiarRegistrosIncorrectos(
                $espacio->id_espacio,
                $fechaActual,
                $horaActual,
                $profesor->run_profesor
            );

            return response()->json([
                'success' => true,
                'mensaje' => 'Reserva creada exitosamente para el profesor',
                'reserva' => [
                    'id' => $reserva->id_reserva,
                    'profesor' => $profesor->name,
                    'run_profesor' => $profesor->run_profesor,
                    'espacio' => $espacio->nombre_espacio,
                    'fecha' => $fechaActual,
                    'hora_inicio' => $horaActual
                ]
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::error('Error de validación al crear reserva de profesor: ' . json_encode($e->errors()));
            return response()->json([
                'success' => false,
                'mensaje' => 'Error de validación en los datos enviados',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error al crear reserva de profesor: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'mensaje' => 'Error al crear reserva: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener asignaturas de un profesor
     * Asegura que SIEMPRE se retornen las asignaturas con eager loading
     */
    public function getAsignaturasProfesor($run)
    {
        try {            // Establecer contexto del tenant desde el request
            $this->establecerContextoTenant();


            // Buscar profesor con eager loading de asignaturas
            // IMPORTANTE: Incluir run_profesor en el select para que funcione el eager loading
            $profesor = Profesor::with(['asignaturas' => function($query) {
                $query->select('asignaturas.id_asignatura', 'asignaturas.codigo_asignatura', 'asignaturas.nombre_asignatura', 'asignaturas.run_profesor')
                      ->orderBy('asignaturas.codigo_asignatura');
            }])->where('run_profesor', $run)->first();

            if (!$profesor) {
                Log::warning('⚠️ Profesor no encontrado: ' . $run);
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Profesor no encontrado'
                ], 404);
            }

            // Obtener asignaturas - usar la relación cargada
            $asignaturas = $profesor->asignaturas;



            return response()->json([
                'success' => true,
                'asignaturas' => $asignaturas,
                'count' => $asignaturas->count(),
                'profesor' => [
                    'run' => $profesor->run_profesor,
                    'nombre' => $profesor->name
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('❌ Error al obtener asignaturas del profesor: ' . $e->getMessage());
            Log::error('Stack trace: ' . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'mensaje' => 'Error al obtener asignaturas: ' . $e->getMessage(),
                'asignaturas' => []
            ], 500);
        }
    }

    /**
     * Establece el contexto del tenant desde el request
     */
    private function establecerContextoTenant()
    {
        $tenantId = tenant_id() ?? null;
        
        if (!$tenantId) {
            $host = request()->getHost();
            $tenant = Tenant::where('domain', $host)
                ->orWhere('domain', 'LIKE', '%' . $host . '%')
                ->first();
            
            if ($tenant) {
                Config::set('database.connections.tenant.database', $tenant->database);
                DB::purge('tenant');

            }
        }
    }
}
