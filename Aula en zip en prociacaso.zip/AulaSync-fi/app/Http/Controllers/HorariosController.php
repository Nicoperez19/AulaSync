<?php

namespace App\Http\Controllers;

use App\Models\Horario;
use App\Models\Profesor;
use App\Models\Planificacion_Asignatura;
use App\Models\PlanificacionProfesorColaborador;
use App\Models\ProfesorColaborador;
use App\Models\Sede;
use App\Models\Asignatura;
use App\Models\Modulo;
use App\Models\Espacio;
use App\Models\Piso;
use App\Helpers\SemesterHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

class HorariosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // Obtener filtros de la request - usar año y semestre actual por defecto
        $semestreFiltro = $request->input('semestre', SemesterHelper::getCurrentSemester());
        $anioFiltro = $request->input('anio', SemesterHelper::getCurrentAcademicYear());

        // Obtener todos los períodos únicos de los horarios para los filtros
        $periodosDisponibles = Horario::select('periodo')
            ->whereNotNull('periodo')
            ->where('periodo', '!=', '')
            ->distinct()
            ->pluck('periodo')
            ->sort()
            ->values();

        // Separar años y semestres de los períodos
        $aniosDisponibles = [];
        $semestresDisponibles = [];

        foreach ($periodosDisponibles as $periodo) {
            if (preg_match('/^(\d{4})-(\d+)$/', $periodo, $matches)) {
                $anio = $matches[1];
                $semestre = $matches[2];

                if (!in_array($anio, $aniosDisponibles)) {
                    $aniosDisponibles[] = $anio;
                }

                if (!in_array($semestre, $semestresDisponibles)) {
                    $semestresDisponibles[] = $semestre;
                }
            }
        }

        // Asegurar que existan semestres 1 y 2 en las opciones del filtro
        if (!in_array('1', $semestresDisponibles)) {
            $semestresDisponibles[] = '1';
        }
        if (!in_array('2', $semestresDisponibles)) {
            $semestresDisponibles[] = '2';
        }

        // Ordenar arrays
        sort($aniosDisponibles);
        sort($semestresDisponibles);

        $query = Profesor::with(['areaAcademica', 'facultad']);

        if ($request->filled('search')) {
            $search = trim($request->search);
            // Permite buscar RUN con puntos y guion (12.345.678-9 → 123456789)
            $cleanRun = preg_replace('/[^0-9Kk]/', '', $search);
            $query->where(function ($q) use ($search, $cleanRun) {
                $q->where('name', 'like', '%' . $search . '%');

                if ($cleanRun !== '') {
                    $q->orWhere('run_profesor', 'like', '%' . $cleanRun . '%');
                }
            });
        }

        // Filtro por letra inicial del apellido
        if ($request->filled('letra') && $request->letra !== 'Todos') {
            $letra = $request->letra;
            // Quitar tildes y comparar solo la primera letra del apellido
            $query->whereRaw("UPPER(REPLACE(SUBSTRING_INDEX(name, ',', 1), 'Á', 'A')) LIKE ?", [strtoupper($letra) . '%']);
        }

        // Determinar el período seleccionado (nunca mezclar 1° y 2° semestre)
        $periodo = $anioFiltro . '-' . ($semestreFiltro ?: SemesterHelper::getCurrentSemester());

        $query->whereHas('horarios', function ($q) use ($periodo) {
            $q->where('periodo', $periodo);
        });

        // Agregar distinct para evitar duplicados cuando un profesor tiene múltiples horarios
        $profesores = $query->distinct()
            ->orderBy('name')
            ->paginate(27);

        $horarios = Horario::with([
                'profesor',
                'planificaciones' => function ($q) {
                    $q->withoutGlobalScope('vigencia_activa')
                        ->with(['asignatura', 'espacio', 'modulo']);
                }
            ])
            ->where('periodo', $periodo)
            ->get();

        // Formatear las horas de inicio y término de los módulos
        $horarios->each(function ($horario) {
            $horario->planificaciones->each(function ($planificacion) {
                if ($planificacion->modulo) {
                    $planificacion->modulo->hora_inicio = substr($planificacion->modulo->hora_inicio, 0, 5);
                    $planificacion->modulo->hora_termino = substr($planificacion->modulo->hora_termino, 0, 5);
                }
            });
        });

        $horarios = $horarios->groupBy('run_profesor');

        return view('horarios.profesores', compact(
            'profesores',
            'horarios',
            'semestresDisponibles',
            'semestreFiltro',
            'anioFiltro'
        ));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function getHorarioProfesor($run, Request $request)
    {
        try {
            // Obtener el período de los filtros (usar semestre y año actual por defecto)
            $semestreFiltro = $request->input('semestre');
            $anioFiltro = $request->input('anio', SemesterHelper::getCurrentAcademicYear());

            if ($semestreFiltro) {
                $periodo = $anioFiltro . '-' . $semestreFiltro;
            } else {
                // Si no hay semestre seleccionado, usar el semestre actual
                $semestre = SemesterHelper::getCurrentSemester();
                $periodo = $anioFiltro . '-' . $semestre;
            }

            $horario = Horario::with([
                    'profesor',
                    'planificaciones' => function ($q) {
                        $q->withoutGlobalScope('vigencia_activa')
                            ->with(['asignatura', 'espacio', 'modulo']);
                    }
                ])
                ->where('run_profesor', $run)
                ->where('periodo', $periodo)
                ->first();

            // Si se encontró el horario, eliminar posibles duplicados de bloques dentro del mismo período
            if ($horario) {
                $horario->planificaciones = $horario->planificaciones
                    ->filter(function ($planificacion) use ($periodo) {
                        if (!$planificacion->asignatura) {
                            return false;
                        }
                        if (!empty($planificacion->asignatura->periodo) && $planificacion->asignatura->periodo !== $periodo) {
                            return false;
                        }
                        if ($periodo === SemesterHelper::getCurrentPeriod() && !empty($planificacion->fecha_fin_vigencia)) {
                            return false;
                        }
                        return true;
                    })
                    ->unique(function ($plan) {
                        // Evitar duplicados usando combinación de id_modulo y asignatura
                        return $plan->id_modulo . '_' . $plan->id_asignatura;
                    })
                    ->values();
            }

            if (!$horario) {
                Log::warning('Horario no encontrado:', [
                    'run' => $run,
                    'periodo' => $periodo
                ]);

                // Verificar si el profesor existe
                $profesor = Profesor::where('run_profesor', $run)->first();
                if (!$profesor) {
                    return response()->json(['error' => 'Profesor no encontrado'], 404);
                }

                // Devolver respuesta informativa en lugar de error 404
                return response()->json([
                    'profesor' => $profesor,
                    'horario' => null,
                    'asignaturas' => collect([]),
                    'modulos' => Modulo::orderBy('hora_inicio')->get(),
                    'mensaje' => 'El profesor no tiene horario asignado para el período ' . $periodo
                ]);
            }

            // Obtener asignaturas que pertenecen a este horario/período específico
            $asignaturas = Asignatura::where('run_profesor', $run)
                ->whereHas('planificaciones', function ($q) use ($periodo) {
                    $q->withoutGlobalScope('vigencia_activa')
                        ->whereHas('horario', function ($hq) use ($periodo) {
                            $hq->where('periodo', $periodo);
                        });
                })
                ->with([
                    'planificaciones' => function ($q) use ($periodo) {
                        $q->withoutGlobalScope('vigencia_activa')
                            ->whereHas('horario', function ($hq) use ($periodo) {
                                $hq->where('periodo', $periodo);
                            })
                            ->with(['espacio', 'modulo']);
                    }
                ])
                ->get();

            $modulos = Modulo::orderBy('hora_inicio')->get();

            return response()->json([
                'horario' => $horario,
                'asignaturas' => $asignaturas,
                'modulos' => $modulos,
                'periodo' => $periodo
            ]);
        } catch (\Exception $e) {
            Log::error('Error al obtener horario:', [
                'error' => $e->getMessage(),
                'run' => $run
            ]);
            return response()->json(['error' => 'Error al obtener el horario'], 500);
        }
    }
    public function getHorariosEspacios(Request $request)
    {
        try {
            $id_espacio = $request->input('id_espacio');
            $periodo = SemesterHelper::getCurrentPeriod();

            $query = Planificacion_Asignatura::with(['asignatura', 'horario.profesor', 'modulo', 'espacio'])
                ->whereHas('horario', function ($q) use ($periodo) {
                    $q->where('periodo', $periodo);
                });

            if ($id_espacio) {
                $query->where('id_espacio', $id_espacio);
            }

            $planificaciones = $query->get();

            // Agrupar por espacio
            $horariosPorEspacio = $planificaciones->groupBy('id_espacio')->map(function ($items) {
                return $items->map(function ($plan) {
                    return [
                        'asignatura' => $plan->asignatura->nombre_asignatura ?? '',
                        'profesor' => $plan->horario->profesor ? [
                            'name' => $plan->horario->profesor->name
                        ] : null,
                        'dia' => $plan->modulo->dia ?? '',
                        'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                        'hora_termino' => $plan->modulo->hora_termino ?? '',
                        'espacio' => $plan->espacio->nombre_espacio ?? '',
                    ];
                })->unique(function ($item) {
                    return json_encode($item);
                })->values();
            });

            return response()->json([
                'horarios' => $horariosPorEspacio
            ]);
        } catch (\Exception $e) {
            Log::error('Error al obtener horarios de espacios:', [
                'error' => $e->getMessage()
            ]);
            return response()->json(['error' => 'Error al obtener los horarios de los espacios'], 500);
        }
    }

    public function showEspacios(Request $request)
    {
        // Obtener filtros de la request - usar año actual por defecto
        $semestreFiltro = $request->input('semestre');
        $anioFiltro = $request->input('anio', SemesterHelper::getCurrentAcademicYear());

        // Obtener todos los períodos únicos de los horarios para los filtros
        $periodosDisponibles = Horario::select('periodo')
            ->whereNotNull('periodo')
            ->where('periodo', '!=', '')
            ->distinct()
            ->pluck('periodo')
            ->sort()
            ->values();

        // Separar años y semestres de los períodos
        $aniosDisponibles = [];
        $semestresDisponibles = [];

        foreach ($periodosDisponibles as $periodo) {
            if (preg_match('/^(\d{4})-(\d+)$/', $periodo, $matches)) {
                $anio = $matches[1];
                $semestre = $matches[2];

                if (!in_array($anio, $aniosDisponibles)) {
                    $aniosDisponibles[] = $anio;
                }

                if (!in_array($semestre, $semestresDisponibles)) {
                    $semestresDisponibles[] = $semestre;
                }
            }
        }

        // Asegurar que existan semestres 1 y 2 en las opciones del filtro
        if (!in_array('1', $semestresDisponibles)) {
            $semestresDisponibles[] = '1';
        }
        if (!in_array('2', $semestresDisponibles)) {
            $semestresDisponibles[] = '2';
        }

        // Ordenar arrays
        sort($aniosDisponibles);
        sort($semestresDisponibles);

        // Obtener todos los pisos con sus espacios, ordenados por número de piso y código de espacio
        $pisos = Piso::with([
            'espacios' => function ($q) {
                $q->orderBy('id_espacio');
            }
        ])->orderBy('numero_piso')->get();

        // Cargar horarios por defecto para el semestre activo o para los filtros seleccionados
        $horariosPorEspacio = collect([]);

        // Si no hay semestre seleccionado, usar el semestre actual
        if (!$semestreFiltro) {
            $semestreFiltro = SemesterHelper::getCurrentSemester();
        }

        if ($semestreFiltro) {
            $periodo = $anioFiltro . '-' . $semestreFiltro;

            // Cargar horarios para el período seleccionado (Titulares)
            $planificaciones = Planificacion_Asignatura::withoutGlobalScope('vigencia_activa')
                ->with(['asignatura', 'modulo', 'espacio', 'horario.profesor'])
                ->whereHas('horario', function ($q) use ($periodo) {
                    $q->where('periodo', $periodo);
                })
                ->get();

            // Cargar horarios de Colaboradores (Laboratorios, Talleres y Clínicas)
            $planificacionesColab = PlanificacionProfesorColaborador::withoutGlobalScope('vigencia_activa')
                ->with([
                    'modulo',
                    'espacio',
                    'profesorColaborador.profesor',
                    'profesorColaborador.asignatura'
                ])
                ->whereHas('modulo')
                ->whereHas('profesorColaborador')
                ->get();

            $itemsColab = $planificacionesColab->filter(function ($plan) use ($periodo) {
                $colab = $plan->profesorColaborador;
                return SemesterHelper::perteneceColaboradorAPeriodo($colab, $periodo, $plan);
            })->map(function ($plan) use ($periodo) {
                $colab = $plan->profesorColaborador;
                return [
                    'id_espacio' => $plan->id_espacio,
                    'asignatura' => $colab->asignatura->nombre_asignatura ?? $colab->nombre_asignatura_temporal ?? '',
                    'codigo_asignatura' => $colab->asignatura->codigo_asignatura ?? '',
                    'profesor' => ($colab && $colab->profesor) ? [
                        'name' => $colab->profesor->name
                    ] : null,
                    'dia' => $plan->modulo->dia ?? '',
                    'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                    'hora_termino' => $plan->modulo->hora_termino ?? '',
                    'espacio' => $plan->espacio->nombre_espacio ?? '',
                    'periodo' => $periodo,
                ];
            });

            $itemsTitulares = $planificaciones->map(function ($plan) {
                return [
                    'id_espacio' => $plan->id_espacio,
                    'asignatura' => $plan->asignatura->nombre_asignatura ?? '',
                    'codigo_asignatura' => $plan->asignatura->codigo_asignatura ?? '',
                    'profesor' => $plan->horario->profesor ? [
                        'name' => $plan->horario->profesor->name
                    ] : null,
                    'dia' => $plan->modulo->dia ?? '',
                    'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                    'hora_termino' => $plan->modulo->hora_termino ?? '',
                    'espacio' => $plan->espacio->nombre_espacio ?? '',
                    'periodo' => $plan->horario->periodo ?? '',
                ];
            });

            // Agrupar ambos por espacio asegurando que no se dupliquen
            $horariosPorEspacio = $itemsTitulares->concat($itemsColab)->groupBy('id_espacio')->map(function ($items) {
                return $items->unique(function ($item) {
                    return ($item['codigo_asignatura'] ?? '') . '_' .
                           ($item['dia'] ?? '') . '_' .
                           ($item['hora_inicio'] ?? '') . '_' .
                           ($item['profesor']['name'] ?? '');
                })->values();
            });
        }

        // Definir variables para la vista
        $semestre = $semestreFiltro ?: SemesterHelper::getCurrentSemester();
        $anioActual = $anioFiltro;

        return view('horarios.espacios', compact(
            'pisos',
            'horariosPorEspacio',
            'semestre',
            'anioActual',
            'semestresDisponibles',
            'semestreFiltro',
            'anioFiltro'
        ));
    }

    public function getHorariosPorPeriodo(Request $request)
    {
        try {
            $semestreFiltro = $request->input('semestre');
            $anioFiltro = $request->input('anio', SemesterHelper::getCurrentAcademicYear());

            if (!$semestreFiltro) {
                return response()->json(['error' => 'Se requiere semestre'], 400);
            }

            $periodo = $anioFiltro . '-' . $semestreFiltro;
            
            // Log inicial simplificado
            $tenant = tenant();


            // Verificar datos en BD (Titulares)
            $planificaciones = Planificacion_Asignatura::withoutGlobalScope('vigencia_activa')
                ->with(['asignatura', 'modulo', 'espacio', 'horario.profesor'])
                ->whereHas('horario', function ($q) use ($periodo) {
                    $q->where('periodo', $periodo);
                })
                ->get();

            // Cargar horarios de Colaboradores (Laboratorios, Talleres y Clínicas)
            $planificacionesColab = PlanificacionProfesorColaborador::withoutGlobalScope('vigencia_activa')
                ->with([
                    'modulo',
                    'espacio',
                    'profesorColaborador.profesor',
                    'profesorColaborador.asignatura'
                ])
                ->whereHas('modulo')
                ->whereHas('profesorColaborador')
                ->get();

            $itemsColab = $planificacionesColab->filter(function ($plan) use ($periodo) {
                $colab = $plan->profesorColaborador;
                return SemesterHelper::perteneceColaboradorAPeriodo($colab, $periodo, $plan);
            })->map(function ($plan) use ($periodo) {
                $colab = $plan->profesorColaborador;
                return [
                    'id_espacio' => $plan->id_espacio,
                    'asignatura' => $colab->asignatura->nombre_asignatura ?? $colab->nombre_asignatura_temporal ?? '',
                    'codigo_asignatura' => $colab->asignatura->codigo_asignatura ?? '',
                    'profesor' => ($colab && $colab->profesor) ? [
                        'name' => $colab->profesor->name
                    ] : null,
                    'dia' => $plan->modulo->dia ?? '',
                    'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                    'hora_termino' => $plan->modulo->hora_termino ?? '',
                    'espacio' => $plan->espacio->nombre_espacio ?? '',
                    'periodo' => $periodo,
                ];
            });

            $itemsTitulares = $planificaciones->map(function ($plan) {
                return [
                    'id_espacio' => $plan->id_espacio,
                    'asignatura' => $plan->asignatura->nombre_asignatura ?? '',
                    'codigo_asignatura' => $plan->asignatura->codigo_asignatura ?? '',
                    'profesor' => $plan->horario->profesor ? [
                        'name' => $plan->horario->profesor->name
                    ] : null,
                    'dia' => $plan->modulo->dia ?? '',
                    'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                    'hora_termino' => $plan->modulo->hora_termino ?? '',
                    'espacio' => $plan->espacio->nombre_espacio ?? '',
                    'periodo' => $plan->horario->periodo ?? '',
                ];
            });

            // Agrupar ambos por espacio
            $horariosPorEspacio = $itemsTitulares->concat($itemsColab)->groupBy('id_espacio')->map(function ($items) {
                return $items->unique(function ($item) {
                    return ($item['codigo_asignatura'] ?? '') . '_' .
                           ($item['dia'] ?? '') . '_' .
                           ($item['hora_inicio'] ?? '') . '_' .
                           ($item['profesor']['name'] ?? '');
                })->values();
            });

            return response()->json([
                'horariosPorEspacio' => $horariosPorEspacio,
                'periodo' => $periodo
            ]);
        } catch (\Exception $e) {
            Log::error('Error al obtener horarios por período:', [
                'error' => $e->getMessage()
            ]);
            return response()->json(['error' => 'Error al obtener los horarios'], 500);
        }
    }

    public function exportHorarioEspacioPDF($idEspacio, Request $request)
    {
        try {
            // Obtener el espacio con sus relaciones
            $espacio = Espacio::with(['piso.facultad'])->where('id_espacio', $idEspacio)->first();

            if (!$espacio) {
                Log::warning("⚠ Espacio '$idEspacio' no encontrado para export PDF");
                return response()->json(['error' => 'Espacio no encontrado'], 404);
            }

            // Obtener el período de los filtros o usar el actual
            $semestreFiltro = $request->input('semestre');
            $anioFiltro = $request->input('anio');

            if ($semestreFiltro && $anioFiltro) {
                $periodo = $anioFiltro . '-' . $semestreFiltro;
            } else {
                // Determinar el período actual usando el helper
                $anioActual = SemesterHelper::getCurrentAcademicYear();
                $semestre = SemesterHelper::getCurrentSemester();
                $periodo = SemesterHelper::getCurrentPeriod();
            }

            // Obtener las planificaciones del espacio (Titulares)
            $planificaciones = Planificacion_Asignatura::withoutGlobalScope('vigencia_activa')
                ->with(['asignatura', 'horario.profesor', 'modulo'])
                ->where('id_espacio', $idEspacio)
                ->whereHas('horario', function ($q) use ($periodo) {
                    $q->where('periodo', $periodo);
                })
                ->get();

            // Obtener planificaciones del espacio (Colaboradores)
            $planificacionesColab = PlanificacionProfesorColaborador::withoutGlobalScope('vigencia_activa')
                ->with(['modulo', 'profesorColaborador.profesor', 'profesorColaborador.asignatura'])
                ->where('id_espacio', $idEspacio)
                ->whereHas('modulo')
                ->whereHas('profesorColaborador')
                ->get();

            $horariosColab = $planificacionesColab->filter(function ($plan) use ($periodo) {
                $colab = $plan->profesorColaborador;
                return SemesterHelper::perteneceColaboradorAPeriodo($colab, $periodo, $plan);
            })->map(function ($plan) {
                $colab = $plan->profesorColaborador;
                return [
                    'asignatura' => $colab->asignatura->nombre_asignatura ?? $colab->nombre_asignatura_temporal ?? '',
                    'codigo_asignatura' => $colab->asignatura->codigo_asignatura ?? '',
                    'profesor' => ($colab && $colab->profesor) ? [
                        'name' => $colab->profesor->name
                    ] : null,
                    'dia' => $plan->modulo->dia ?? '',
                    'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                    'hora_termino' => $plan->modulo->hora_termino ?? '',
                ];
            });

            // Formatear los horarios titulares
            $horariosTitulares = $planificaciones->map(function ($plan) {
                return [
                    'asignatura' => $plan->asignatura->nombre_asignatura ?? '',
                    'codigo_asignatura' => $plan->asignatura->codigo_asignatura ?? '',
                    'profesor' => $plan->horario->profesor ? [
                        'name' => $plan->horario->profesor->name
                    ] : null,
                    'dia' => $plan->modulo->dia ?? '',
                    'hora_inicio' => $plan->modulo->hora_inicio ?? '',
                    'hora_termino' => $plan->modulo->hora_termino ?? '',
                ];
            });

            $horarios = $horariosTitulares->concat($horariosColab)->unique(function ($item) {
                return ($item['codigo_asignatura'] ?? '') . '_' .
                       ($item['dia'] ?? '') . '_' .
                       ($item['hora_inicio'] ?? '') . '_' .
                       ($item['profesor']['name'] ?? '');
            })->values()->toArray();

            // Obtener TODOS los módulos disponibles desde las 8:10 hasta el último horario
            $todosLosModulos = Modulo::orderBy('hora_inicio')->get();

            // Filtrar módulos que empiecen desde las 8:10 o después
            $modulosFiltrados = $todosLosModulos->filter(function ($modulo) {
                return $modulo->hora_inicio >= '08:10:00';
            });

            // Obtener módulos únicos y ordenarlos
            $modulosUnicos = $modulosFiltrados->map(function ($modulo) {
                return [
                    'hora_inicio' => $modulo->hora_inicio,
                    'hora_termino' => $modulo->hora_termino
                ];
            })->unique(function ($item) {
                return $item['hora_inicio'] . '-' . $item['hora_termino'];
            })->sortBy('hora_inicio')
                ->values()
                ->toArray();

            $fecha_generacion = Carbon::now()->format('d/m/Y H:i:s');
            // Fecha simple para mostrar en el encabezado del PDF
            $fecha = Carbon::now()->format('d/m/Y');

            // Preparar variables para la vista PDF (asegurar que existan)
            $moduloInicio = 1;
            $moduloFin = max(1, count($modulosUnicos));
            $modulosDia = $moduloFin - $moduloInicio + 1;

            // Preparar datos para la tabla de horarios (igual que en el modal)
            $datos = [];
            $diasSemana = ['LU', 'MA', 'MI', 'JU', 'VI', 'SA'];
            
            // Obtener módulos únicos ordenados (igual que en el modal)
            $modulosUnicos = $planificaciones->pluck('modulo.id_modulo')
                ->map(function($idModulo) {
                    return explode('.', $idModulo)[1] ?? '';
                })
                ->unique()
                ->sort(function($a, $b) {
                    return intval($a) - intval($b);
                })
                ->values();
            
            // Crear una tabla con módulos en filas y días en columnas
            foreach ($modulosUnicos as $modulo) {
                // Encontrar información del módulo
                $moduloInfo = $planificaciones->first(function($plan) use ($modulo) {
                    return explode('.', $plan->modulo->id_modulo)[1] == $modulo;
                });
                
                if (!$moduloInfo) continue;
                
                $horaInicio = substr($moduloInfo->modulo->hora_inicio, 0, 5);
                $horaTermino = substr($moduloInfo->modulo->hora_termino, 0, 5);
                $hora = $horaInicio . ' a ' . $horaTermino;
                
                $row = [
                    'hora' => $hora,
                    'modulo' => $modulo
                ];
                
                // Para cada día de la semana
                foreach ($diasSemana as $dia) {
                    // Filtrar planificaciones por día y módulo (igual que en el modal)
                    $planificacionesDia = $planificaciones->filter(function ($plan) use ($dia, $modulo) {
                        $planDia = explode('.', $plan->modulo->id_modulo)[0] ?? '';
                        $planModulo = explode('.', $plan->modulo->id_modulo)[1] ?? '';
                        return $planDia === $dia && $planModulo === $modulo;
                    });
                    
                    if ($planificacionesDia->count() > 0) {
                        // Mostrar información de las asignaturas (igual que en el modal)
                        $infoAsignaturas = $planificacionesDia->map(function ($plan) {
                            $asignatura = $plan->asignatura->nombre_asignatura ?? '';
                            $espacio = $plan->espacio->id_espacio ?? '';
                            $codigo = $plan->asignatura->codigo_asignatura ?? '';
                            return [
                                'asignatura' => $asignatura,
                                'espacio' => $espacio,
                                'codigo' => $codigo
                            ];
                        })->toArray();
                        
                        $row[$dia] = $infoAsignaturas;
                    } else {
                        $row[$dia] = null; // Libre
                    }
                }
                
                $datos[] = $row;
            }

            // Generar el PDF
            $pdf = Pdf::loadView('reportes.pdf.horarios-espacio', compact(
                'espacio',
                'horarios',
                'modulosUnicos',
                'fecha_generacion',
                'fecha',
                'moduloInicio',
                'moduloFin',
                'modulosDia',
                'datos'
            ));

            // Usar orientación horizontal para que quepan más columnas en la página
            try {
                $pdf->setPaper('a4', 'landscape');
            } catch (\Throwable $e) {
                // Algunos drivers/no configuraciones podrían no soportar setPaper; ignorar si falla
                Log::warning('No se pudo forzar orientación landscape en dompdf: ' . $e->getMessage());
            }

            // Formato del nombre: espacio_horario_2025_1.pdf
            $filename = $idEspacio . '_horario_' . str_replace('-', '_', $periodo) . '.pdf';



            return $pdf->download($filename);

        } catch (\Exception $e) {
            Log::error('Error al exportar horario de espacio a PDF:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'id_espacio' => $idEspacio
            ]);

            return response()->json([
                'error' => 'Error al generar el PDF: ' . $e->getMessage()
            ], 500);
        }
    }
}
