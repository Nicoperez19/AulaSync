<?php

namespace App\Http\Controllers;

use App\Helpers\EspacioAliasHelper;
use App\Models\Asignatura;
use App\Models\Carrera;
use App\Models\DataLoad;
use App\Models\Espacio;
use App\Models\Facultad;
use App\Models\Horario;
use App\Models\Modulo;
use App\Models\Piso;
use App\Models\Planificacion_Asignatura;
use App\Models\Profesor;
use App\Models\ProfesorColaborador;
use App\Models\Sede;
use App\Services\QRService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use App\Helpers\ModulosHelper;
use App\Helpers\SemesterHelper;

class DataLoadController extends Controller
{
    protected $qrService;

    public function __construct(QRService $qrService)
    {
        $this->qrService = $qrService;
    }

    public function index(Request $request)
    {
        $semestreFiltro = $request->input('semestre');
        $anioFiltro = $request->input('anio');

        $periodosDisponibles = Horario::select('periodo')
            ->whereNotNull('periodo')
            ->where('periodo', '!=', '')
            ->distinct()
            ->pluck('periodo')
            ->sort()
            ->values();

        $aniosDisponibles = [];
        $semestresDisponibles = [];

        foreach ($periodosDisponibles as $periodo) {
            if (preg_match('/^(\d{4})-(\d+)$/', $periodo, $matches)) {
                $anio = $matches[1];
                $semestre = $matches[2];

                if (!in_array($anio, $aniosDisponibles)) {
                    $aniosDisponibles[] = $anio;
                }

                if (!in_array($semestre, $semestresDisponibles)) {
                    $semestresDisponibles[] = $semestre;
                }
            }
        }

        sort($aniosDisponibles);
        sort($semestresDisponibles);

        $query = DataLoad::latest();

        if ($semestreFiltro && $anioFiltro) {
            $periodoFiltro = $anioFiltro . '-' . $semestreFiltro;

            $query->whereHas('profesor.horarios', function ($q) use ($periodoFiltro) {
                $q->where('periodo', $periodoFiltro);
            });
        } elseif ($anioFiltro) {
            $query->whereHas('profesor.horarios', function ($q) use ($anioFiltro) {
                $q->where('periodo', 'like', $anioFiltro . '-%');
            });
        }

        $dataLoads = $query->paginate(10);

        return view('data.index', compact(
            'dataLoads',
            'aniosDisponibles',
            'semestresDisponibles',
            'semestreFiltro',
            'anioFiltro'
        ));
    }

    public function upload(Request $request)
    {
        set_time_limit(300);

        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv|max:10240',
            'semestre_selector' => 'required|in:1,2'
        ]);

        $semestreSeleccionado = $request->input('semestre_selector');
        // Usar el año académico configurado en lugar de la fecha del sistema
        $anioActual = \App\Helpers\SemesterHelper::getCurrentAcademicYear();
        $periodoSeleccionado = $anioActual . '-' . $semestreSeleccionado;

        try {
            $file = $request->file('file');
            $fileName = $file->getClientOriginalName();
            $fileExtension = $file->getClientOriginalExtension();

            $uniqueFileName = date('Y-m-d_His') . '_' . Auth::user()->run . '_' . Str::random(10) . '.' . $fileExtension;
            $path = $file->storeAs('datos_subidos', $uniqueFileName, 'public');

            $dataLoad = DataLoad::create([
                'nombre_archivo' => $fileName,
                'ruta_archivo' => $path,
                'tipo_carga' => $fileExtension,
                'registros_cargados' => 0,
                'estado' => 'pendiente',
                'user_run' => Auth::user()->run
            ]);

            $rows = Excel::toArray([], $file)[0];
            $processedUsersCount = 0;
            $processedAsignaturasCount = 0;
            $processedHorariosCount = 0;
            $errors = [];
            $skippedRows = 0;
            $skippedBySede = 0;           // Filas rechazadas por no coincidir con la sede
            $skippedByColaborador = 0;    // Filas saltadas porque el profesor es colaborador
            $espaciosOtrosTenants = 0;    // Espacios que no pertenecen a este tenant
            $espaciosNoEncontrados = 0;   // Espacios del tenant que no existen en BD
            $espaciosFaltantes = [];      // Lista de espacios que no se encontraron en BD

            // Encabezados de la primera fila
            $headers = isset($rows[0]) ? array_map(function($h) {
                return strtoupper(trim(preg_replace('/[^A-Za-z0-9_]/', '', (string)$h)));
            }, $rows[0]) : [];

            // ── NUEVA CAPA DE SEGURIDAD: VERIFICACIÓN DEL SEMESTRE EN EL ARCHIVO ──
            $posiblesHeadersSemestre = [
                'SEMESTRE', 'SEM', 'SEMESTRE_ACADEMICO', 'SEMESTREACADEMICO',
                'PERIODO', 'PERIODO_ACADEMICO', 'PERIODOACADEMICO',
                'COD_PERIODO', 'CODPERIODO', 'CODIGO_PERIODO', 'CODIGOPERIODO',
                'ANIO_SEMESTRE', 'ANIOSEMESTRE', 'TERMINO', 'TERM'
            ];

            $colSemestreIdx = null;
            $colPeriodoAcademicoIdx = null;
            $headerPeriodoAcademicoEncontrado = null;
            $headersPeriodoAcademico = [
                'SEMESTRE', 'SEMESTRE_ACADEMICO', 'SEMESTREACADEMICO',
                'PERIODO', 'PERIODO_ACADEMICO', 'PERIODOACADEMICO',
                'COD_PERIODO', 'CODPERIODO', 'CODIGO_PERIODO', 'CODIGOPERIODO',
                'ANIO_SEMESTRE', 'ANIOSEMESTRE'
            ];
            foreach ($headers as $colIdx => $headerName) {
                if ($colSemestreIdx === null && in_array($headerName, $posiblesHeadersSemestre)) {
                    $colSemestreIdx = $colIdx;
                }

                // Nota: si "SEMESTRE" contiene niveles curriculares (3, 4, 5...), $esMallaCurricular lo descarta más abajo.
                // En planificaciones UCSC la columna se llama "SEMESTRE" y trae "2026-1" o "2026-2".
                if ($colPeriodoAcademicoIdx === null && in_array($headerName, $headersPeriodoAcademico)) {
                    $colPeriodoAcademicoIdx = $colIdx;
                    $headerPeriodoAcademicoEncontrado = $headerName;
                }
            }

            if ($colPeriodoAcademicoIdx !== null) {
                $parseSemestreValor = function($val) {
                    if ($val === null || $val === '') return null;
                    $v = strtoupper(trim((string)$val));

                    // Formatos con año: 2026-1, 2026-2, 2026/1, 2026/2, 2026_1, 2026_2
                    if (preg_match('/(?:\d{4}|\d{2})[-_\/]([12])\b/', $v, $m)) {
                        return (int)$m[1];
                    }
                    // Formatos compactos: 202610, 202620, 20261, 20262
                    if (preg_match('/^\d{4}([12])0?$/', $v, $m)) {
                        return (int)$m[1];
                    }
                    // Textos descriptivos
                    if (str_contains($v, 'SEGUNDO') || str_contains($v, '2DO') || str_contains($v, '2°') || str_contains($v, '2DO.')) {
                        return 2;
                    }
                    if (str_contains($v, 'PRIMER') || str_contains($v, '1ER') || str_contains($v, '1°') || str_contains($v, '1ER.')) {
                        return 1;
                    }
                    // Dígito exacto 1 o 2
                    if ($v === '1' || $v === '2') {
                        return (int)$v;
                    }
                    // Otros números (ej: 3 al 12) -> corresponden a nivel curricular de malla, no a período
                    if (is_numeric($v)) {
                        return (int)$v;
                    }
                    return null;
                };

                $conteoSemestres = [1 => 0, 2 => 0, 'otros' => 0];
                $filasVerificadas = 0;

                for ($r = 1; $r < count($rows); $r++) {
                    $rawVal = $rows[$r][$colPeriodoAcademicoIdx] ?? null;
                    $res = $parseSemestreValor($rawVal);
                    if ($res === 1 || $res === 2) {
                        $conteoSemestres[$res]++;
                        $filasVerificadas++;
                    } elseif ($res !== null) {
                        $conteoSemestres['otros']++;
                    }
                }

                // Si predominan números mayores a 2, es nivel curricular de carrera, no período académico
                $esMallaCurricular = $conteoSemestres['otros'] > 0 && ($conteoSemestres['otros'] / max(1, $filasVerificadas + $conteoSemestres['otros'])) > 0.15;

                if (!$esMallaCurricular && $filasVerificadas > 0) {
                    $semestreArchivo = $conteoSemestres[1] > $conteoSemestres[2] ? 1 : 2;
                    $semestreSeleccionadoInt = (int)$semestreSeleccionado;

                    // Si la mayoría del archivo contiene un semestre DISTINTO al que seleccionó el usuario
                    if ($semestreArchivo !== $semestreSeleccionadoInt && ($conteoSemestres[$semestreArchivo] / $filasVerificadas) >= 0.7) {
                        // Eliminar archivo temporal recién subido
                        if (\Illuminate\Support\Facades\Storage::disk('public')->exists($path)) {
                            \Illuminate\Support\Facades\Storage::disk('public')->delete($path);
                        }
                        $dataLoad->update([
                            'estado' => 'error',
                            'registros_cargados' => 0
                        ]);

                        $msgError = "Inconsistencia de Semestre: El archivo contiene asignaturas del Semestre {$semestreArchivo} (detectado en columna '{$headerPeriodoAcademicoEncontrado}' con {$conteoSemestres[$semestreArchivo]} filas), pero seleccionaste el Semestre {$semestreSeleccionadoInt} en el formulario. Por favor verifica el archivo o selecciona el Semestre {$semestreArchivo} para procesarlo.";
                        Log::warning("⛔ " . $msgError);

                        return response()->json([
                            'message' => $msgError
                        ], 422);
                    }

                    Log::info("✓ Verificación de semestre exitosa: la columna '{$headerPeriodoAcademicoEncontrado}' coincide con el Semestre {$semestreSeleccionadoInt} seleccionado ({$conteoSemestres[$semestreSeleccionadoInt]} filas verificadas).");
                }
            }

            // Actualizar estado inicial
            $dataLoad->update([
                'estado' => 'procesando',
                'registros_cargados' => 0
            ]);

            // Asegurar separación de semestres previos antes de procesar la carga
            SemesterHelper::asegurarSeparacionSemestres($periodoSeleccionado, true);

            // Limpieza de horarios y planificaciones previas del mismo período antes de cargar la nueva programación
            Log::info('Iniciando reemplazo de programación previa del período: ' . $periodoSeleccionado);
            $limitesCarga = SemesterHelper::getLimitesPeriodo($periodoSeleccionado);
            $inicioVigenciaPeriodo = $limitesCarga['inicio']->toDateString();
            $periodoActualReal = SemesterHelper::getCurrentAcademicYear() . '-' . SemesterHelper::getCurrentSemester();
            $finVigenciaPeriodo = ($periodoSeleccionado !== $periodoActualReal) ? $limitesCarga['fin']->toDateString() : null;

            $horariosDelPeriodo = Horario::where('periodo', $periodoSeleccionado)->pluck('id_horario');
            if ($horariosDelPeriodo->isNotEmpty()) {
                $planificacionesEliminadas = Planificacion_Asignatura::withoutGlobalScope('vigencia_activa')
                    ->whereIn('id_horario', $horariosDelPeriodo)
                    ->delete();
                Horario::whereIn('id_horario', $horariosDelPeriodo)->delete();
                Log::info("Programación titular previa de {$periodoSeleccionado} reemplazada: {$planificacionesEliminadas} bloques eliminados.");
            }

            // Limpiar planificaciones de colaboradores previas de este mismo período
            $colabsTenantIds = ProfesorColaborador::where('fecha_inicio', '>=', $limitesCarga['inicio']->toDateString())
                ->where('fecha_termino', '<=', $limitesCarga['fin']->toDateString())
                ->pluck('id');
            if ($colabsTenantIds->isNotEmpty()) {
                $planifColabsEliminadas = \App\Models\PlanificacionProfesorColaborador::withoutGlobalScope('vigencia_activa')
                    ->whereIn('id_profesor_colaborador', $colabsTenantIds)
                    ->delete();
                ProfesorColaborador::whereIn('id', $colabsTenantIds)->delete();
                Log::info("Programación de colaboradores previa de {$periodoSeleccionado} reemplazada: {$planifColabsEliminadas} bloques eliminados.");
            }

            // GARANTIZAR QUE EXISTAN MÓDULOS: Sin ellos la FK falla y 0 planificaciones se crean
            $modulosExistentes = Modulo::count();
            if ($modulosExistentes === 0) {
                Log::info('⚠ Tabla modulos VACÍA - Creando módulos automáticamente...');
                $dias = [
                    'LU' => 'lunes',
                    'MA' => 'martes',
                    'MI' => 'miércoles',
                    'JU' => 'jueves',
                    'VI' => 'viernes',
                    'SA' => 'sábado',
                ];
                $horariosModulos = ModulosHelper::getHorariosModulos();
                $modulosCreados = 0;
                foreach ($dias as $codigoDia => $nombreDia) {
                    $claveDia = ModulosHelper::normalizarDia($nombreDia);
                    $modulosDia = $horariosModulos[$claveDia] ?? [];

                    foreach ($modulosDia as $numeroModulo => $horario) {
                        $idModulo = $codigoDia . '.' . $numeroModulo;
                        Modulo::firstOrCreate(
                            ['id_modulo' => $idModulo],
                            ['dia' => $nombreDia, 'hora_inicio' => $horario['inicio'], 'hora_termino' => $horario['fin']]
                        );
                        $modulosCreados++;
                    }
                }
                Log::info("✓ Módulos creados: {$modulosCreados} (LU-VI: 15 módulos, SA: 6 módulos)");
            } else {
                Log::info("✓ Módulos existentes en BD: {$modulosExistentes}");
            }

            // PRESERVAR ESPACIOS DEL SEEDER: Solo eliminar espacios SIN piso_id válido (creados por cargas anteriores)
            // Los espacios con piso_id configurado vienen del seeder y deben mantenerse
            $tenant = \App\Models\Tenant::current();
            if ($tenant) {
                // Contar espacios del seeder (con piso_id configurado)
                $espaciosSeeder = Espacio::whereNotNull('piso_id')->count();
                // Eliminar solo espacios sin piso_id (generados por cargas masivas previas)
                $espaciosEliminados = Espacio::whereNull('piso_id')->delete();
                Log::info('Espacios del seeder preservados: ' . $espaciosSeeder);
                Log::info('Espacios sin piso eliminados del tenant ' . $tenant->domain . ': ' . $espaciosEliminados);
            }

            // Obtener la sede actual del tenant
            $sedeActual = $tenant ? Sede::find($tenant->sede_id) : null;
            $nombreSedeActual = $sedeActual ? strtolower(trim($sedeActual->nombre_sede)) : null;
            $idSedeActual = $sedeActual ? strtolower(trim($sedeActual->id_sede)) : null;
            $prefijoSalaActual = $sedeActual ? strtolower(trim($sedeActual->prefijo_sala ?? '')) : null;
            $prefijoTenantFiltro = ($tenant && $tenant->prefijo_espacios) ? strtoupper(trim($tenant->prefijo_espacios)) : '';

            // Obtener la primera facultad de la sede para crear carreras automáticamente si es necesario
            $facultadDeLaSede = $sedeActual ? Facultad::where('id_sede', $sedeActual->id_sede)->first() : null;

            // LOGS DETALLADOS DE CONFIGURACIÓN DEL TENANT
            Log::info('═══════════════════════════════════════════════════════════');
            Log::info('🔧 CONFIGURACIÓN DEL TENANT PARA IMPORTACIÓN');
            Log::info('  → Tenant ID: ' . ($tenant ? $tenant->id : 'NO CONFIGURADO'));
            Log::info('  → Prefijo espacios (raw): "' . ($tenant && $tenant->prefijo_espacios ? $tenant->prefijo_espacios : 'NO CONFIGURADO') . '"');
            Log::info('  → Prefijo espacios (normalizado): "' . $prefijoTenantFiltro . '"');
            Log::info('  → Sede ID: ' . ($tenant ? $tenant->sede_id : 'N/A'));
            Log::info('  → Nombre sede: ' . ($nombreSedeActual ?? 'N/A'));
            Log::info('  → Filtro espacios: ' . ($prefijoTenantFiltro ? $prefijoTenantFiltro . '-*' : 'NO CONFIGURADO'));
            Log::info('═══════════════════════════════════════════════════════════');

            // Si no existe facultad, crear una genérica para la sede
            if ($sedeActual && !$facultadDeLaSede) {
                try {
                    $facultadDeLaSede = Facultad::create([
                        'id_facultad' => $sedeActual->id_sede . '_FAC',
                        'nombre_facultad' => 'Facultad de ' . $sedeActual->nombre_sede,
                        'id_sede' => $sedeActual->id_sede,
                        'id_universidad' => $sedeActual->id_universidad,
                    ]);
                    Log::info('Facultad genérica creada: ' . $facultadDeLaSede->id_facultad);
                } catch (\Exception $e) {
                    Log::error('No se pudo crear facultad genérica: ' . $e->getMessage());
                }
            }

            // IMPORTANTE: Los espacios YA DEBEN EXISTIR en la BD (creados manualmente o por seeder)
            // No se crean espacios durante la importación, solo se usan los existentes
            Log::info('✓ Espacios existentes en BD del tenant: ' . Espacio::count() . ' (no se crearán nuevos)');

            // Encabezados de la primera fila
            $headers = isset($rows[0]) ? array_map(function($h) {
                return strtoupper(trim(preg_replace('/[^A-Za-z0-9_]/', '', (string)$h)));
            }, $rows[0]) : [];

            // FORMATO ESTÁNDAR PARA TODAS LAS SEDES
            $colMap = [
                'id_asignatura' => 0,
                'codigo_asignatura' => 1,
                'nombre_asignatura' => 2,
                'seccion' => 3,
                'sede' => 7,
                'inscritos' => 9,
                'run_profesor' => 11,
                'nombre_profesor' => 12,
                'email_profesor' => 13,
                'tipo_profesor' => 16,
                'id_carrera' => 17,
                'nombre_carrera' => 18,
                'horario' => 19,
                'horario_profesor' => 20,
            ];
            $tieneColumnaHorarioProfesor = false;

            // Ajustar dinámicamente si los encabezados varían ligeramente en el formato estándar
            foreach ($headers as $colIdx => $headerName) {
                if (in_array($headerName, ['RUN_PROFESOR', 'RUN_PROF', 'RUT_PROFESOR'])) $colMap['run_profesor'] = $colIdx;
                if (in_array($headerName, ['NOMBRE_PROFESOR', 'NOMBRE_PROF'])) $colMap['nombre_profesor'] = $colIdx;
                if (in_array($headerName, ['HORARIO', 'HORARIOS', 'BLOQUES'])) $colMap['horario'] = $colIdx;
                if (in_array($headerName, ['HORARIO_PROFESOR', 'HORARIOPROFESOR', 'HORARIO_PROF', 'HORARIO_DOCENTE', 'HORARIODOCENTE', 'HORARIO_DOCENTES', 'HORARIODOCENTES', 'HORARIO_PROFESORES', 'HORARIOPROFESORES', 'HORARIO_POR_DOCENTE', 'HORARIOPORDOCENTE', 'HORARIO_POR_PROFESOR', 'HORARIOPORPROFESOR'])) {
                    $colMap['horario_profesor'] = $colIdx;
                    $tieneColumnaHorarioProfesor = true;
                }
                if (in_array($headerName, ['TIPO_PROFESOR', 'TIPOPROFESOR', 'TIPO_DOCENTE', 'TIPODOCENTE', 'TIPO_DE_DOCENTE', 'TIPODEDOCENTE', 'ROL_DOCENTE', 'ROLDOCENTE', 'CARGO_DOCENTE', 'CARGODOCENTE'])) $colMap['tipo_profesor'] = $colIdx;
                if (in_array($headerName, ['SEDE', 'NOMBRE_SEDE'])) $colMap['sede'] = $colIdx;
                if (in_array($headerName, ['UA', 'UNIDAD_ACADEMICA', 'UNIDADACADEMICA', 'ID_CARRERA', 'COD_CARRERA', 'CODCARRERA'])) $colMap['id_carrera'] = $colIdx;
                if (in_array($headerName, ['NOMBRE_CARRERA', 'CARRERA'])) $colMap['nombre_carrera'] = $colIdx;
            }
            if ($colSemestreIdx !== null) {
                $colMap['semestre'] = $colSemestreIdx;
            }
            Log::info('→ Carga estándar aplicada para todas las sedes.');

            Log::info("→ Mapa de columnas activo: " . json_encode($colMap));

            Log::info('→ Iniciando procesamiento de ' . (count($rows) - 1) . ' filas de datos...');

            $colaboradoresAsignados = []; // [id_asignatura => [id_modulo => [id_espacio => true]]]

            foreach ($rows as $index => $row) {
                if ($index === 0) {
                    continue;  // Saltar encabezados
                }

                if ($index === 1) {
                    $asigTest = isset($colMap['id_asignatura']) && isset($row[$colMap['id_asignatura']]) ? $row[$colMap['id_asignatura']] : 'N/A';
                    $sedeTest = isset($colMap['sede']) && isset($row[$colMap['sede']]) ? $row[$colMap['sede']] : 'N/A';
                    $runTest = isset($colMap['run_profesor']) && isset($row[$colMap['run_profesor']]) ? $row[$colMap['run_profesor']] : 'N/A';
                    $horarioTest = isset($colMap['horario']) && isset($row[$colMap['horario']]) ? substr($row[$colMap['horario']], 0, 50) : 'N/A';
                    Log::info("[IMPORT TEST] Fila 1 - Asig: '{$asigTest}', Sede: '{$sedeTest}', RUN: '{$runTest}', Horario: '{$horarioTest}'");
                }

                try {
                    $sedeRaw = isset($colMap['sede']) && isset($row[$colMap['sede']]) ? strtolower(trim($row[$colMap['sede']])) : '';
                    $horarioRaw = isset($row[$colMap['horario']]) ? strtoupper(trim($row[$colMap['horario']])) : '';

                    // Validar coincidencia flexible de sede (por nombre_sede, id_sede ej. 'TH', prefijo, o subcadena)
                    $coincideSede = false;
                    if (!$nombreSedeActual || empty($sedeRaw)) {
                        // Sin configuración de sede → aceptar todas las filas
                        $coincideSede = true;
                    } else {
                        if ($sedeRaw === $nombreSedeActual || ($idSedeActual && $sedeRaw === $idSedeActual) || ($prefijoSalaActual && $sedeRaw === $prefijoSalaActual)) {
                            $coincideSede = true;  // Coincidencia exacta
                        } elseif ($nombreSedeActual && (str_contains($sedeRaw, $nombreSedeActual) || str_contains($nombreSedeActual, $sedeRaw))) {
                            $coincideSede = true;  // Coincidencia por nombre_sede
                        } elseif ($idSedeActual && (str_contains($sedeRaw, $idSedeActual) || str_contains($idSedeActual, $sedeRaw))) {
                            $coincideSede = true;  // Coincidencia por id_sede
                        } elseif ($prefijoTenantFiltro && !empty($horarioRaw) && str_contains($horarioRaw, $prefijoTenantFiltro . '-')) {
                            $coincideSede = true;  // Coincidencia por prefijo en el campo horario
                        }
                        // Si ninguna condición coincide → $coincideSede permanece false (fila rechazada)
                    }

                    if (!$coincideSede) {
                        $skippedBySede++;
                        continue;
                    }

                    $idCarrera = isset($row[$colMap['id_carrera']]) ? trim($row[$colMap['id_carrera']]) : '';

                    // Durante la inicialización o si la carrera no existe, intentar crearla o usar una genérica
                    $carrera = !empty($idCarrera)
                        ? Carrera::withoutGlobalScope(\App\Models\Scopes\TenantScope::class)->find($idCarrera)
                        : null;
                    if (!$carrera && !empty($idCarrera)) {
                        // Intentar crear una carrera genérica para esta sede
                        $nombreCarrera = (isset($colMap['nombre_carrera']) && isset($row[$colMap['nombre_carrera']]) && !empty($row[$colMap['nombre_carrera']]))
                            ? trim($row[$colMap['nombre_carrera']])
                            : 'Carrera ' . $idCarrera;

                        // Necesitamos un área académica genérica para esta facultad
                        if ($facultadDeLaSede) {
                            $areaAcademicaGenerica = \App\Models\AreaAcademica::where('id_facultad', $facultadDeLaSede->id_facultad)->first();

                            if (!$areaAcademicaGenerica) {
                                // Crear un área académica genérica para esta facultad
                                try {
                                    $areaAcademicaGenerica = \App\Models\AreaAcademica::create([
                                        'id_area_academica' => $facultadDeLaSede->id_facultad . '_AA',
                                        'nombre_area_academica' => 'Área Académica de ' . $facultadDeLaSede->nombre_facultad,
                                        'tipo_area_academica' => 'escuela',
                                        'id_facultad' => $facultadDeLaSede->id_facultad,
                                    ]);
                                    Log::info('Área académica genérica creada: ' . $areaAcademicaGenerica->id_area_academica);
                                } catch (\Exception $e) {
                                    Log::warning('Error al crear área académica: ' . $e->getMessage());
                                }
                            }
                        }

                        try {
                            $carrera = Carrera::create([
                                'id_carrera' => $idCarrera,
                                'nombre' => $nombreCarrera,
                                'id_area_academica' => isset($areaAcademicaGenerica) ? $areaAcademicaGenerica->id_area_academica : null,
                            ]);
                            Log::info('Carrera creada automáticamente: ' . $idCarrera . ' - ' . $nombreCarrera);
                        } catch (\Exception $e) {
                            $errors[] = 'Fila ' . ($index + 1) . ': No se pudo crear la carrera ' . $idCarrera;
                            Log::warning('Error al crear carrera ' . $idCarrera . ': ' . $e->getMessage());
                            continue;
                        }
                    }

                    $runRaw = isset($row[$colMap['run_profesor']]) ? trim($row[$colMap['run_profesor']]) : '';
                    $run = preg_replace('/[^0-9Kk]/', '', $runRaw);
                    $run = strtoupper($run);

                    if (empty($run)) {
                        continue;
                    }

                    $name = isset($row[$colMap['nombre_profesor']]) ? trim($row[$colMap['nombre_profesor']]) : '';

                    // Email del docente: si no viene en el Excel, construir un correo válido a partir del nombre o RUN
                    $email = (isset($colMap['email_profesor']) && isset($row[$colMap['email_profesor']])) ? trim($row[$colMap['email_profesor']]) : '';
                    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $nameClean = preg_replace('/[^a-zA-Z0-9]/', '', strtolower(explode(',', $name)[0] ?? $run));
                        $email = !empty($nameClean) ? $nameClean . '@ucsc.cl' : $run . '@ucsc.cl';
                    }

                    $tipoProfesor = (isset($colMap['tipo_profesor']) && isset($row[$colMap['tipo_profesor']])) ? trim($row[$colMap['tipo_profesor']]) : 'Profesor Responsable';

                    // Actualizar/crear el profesor en BD (independiente de si es responsable o colaborador)
                    $existingProfesor = Profesor::withoutGlobalScope('tenant')->where('run_profesor', $run)->first();

                    if ($existingProfesor) {
                        // ACTUALIZACIÓN COMPLETA del profesor
                        $existingProfesor->update([
                            'name' => !empty($name) ? $name : $existingProfesor->name,
                            'email' => !empty($email) ? $email : $existingProfesor->email,
                            'id_carrera' => !empty($idCarrera) ? $idCarrera : $existingProfesor->id_carrera,
                            'tipo_profesor' => !empty($tipoProfesor) ? $tipoProfesor : $existingProfesor->tipo_profesor,
                            'sede_id' => $sedeActual ? $sedeActual->id_sede : null,
                            'id_facultad' => $facultadDeLaSede ? $facultadDeLaSede->id_facultad : null
                        ]);
                        $processedUsersCount++;
                    } else {
                        // Crear nuevo profesor
                        $profesor = Profesor::create([
                            'run_profesor' => $run,
                            'name' => !empty($name) ? $name : 'Profesor ' . $run,
                            'email' => $email,
                            'id_carrera' => !empty($idCarrera) ? $idCarrera : null,
                            'tipo_profesor' => $tipoProfesor,
                            'sede_id' => $sedeActual ? $sedeActual->id_sede : null,
                            'id_facultad' => $facultadDeLaSede ? $facultadDeLaSede->id_facultad : null
                        ]);
                        $processedUsersCount++;
                    }

                    // Los colaboradores y ayudantes se registran aparte del profesor responsable.
                    $tipoProfesorNormalizado = mb_strtolower($tipoProfesor, 'UTF-8');
                    $esProfesorColaborador = str_contains($tipoProfesorNormalizado, 'colaborador')
                        || str_contains($tipoProfesorNormalizado, 'ayudante');
                    if ($esProfesorColaborador) {
                        $idAsignaturaColaborador = isset($row[$colMap['id_asignatura']]) ? trim($row[$colMap['id_asignatura']]) : '';
                        $nombreAsignaturaColaborador = isset($row[$colMap['nombre_asignatura']]) ? preg_replace('/^[a-z]{2}:\s*/i', '', trim($row[$colMap['nombre_asignatura']])) : '';
                        $inscritosColaborador = isset($row[$colMap['inscritos']]) ? (int) $row[$colMap['inscritos']] : 0;
                        $codigoAsignaturaColab = isset($row[$colMap['codigo_asignatura']]) ? trim($row[$colMap['codigo_asignatura']]) : '';
                        $numeroSeccionColab = isset($row[$colMap['seccion']]) ? trim($row[$colMap['seccion']]) : '1';

                        // 1. Asegurar que la asignatura exista con su carrera vinculada
                        if (!empty($idAsignaturaColaborador)) {
                            $asigExistente = Asignatura::withoutGlobalScope('tenant')->where('id_asignatura', $idAsignaturaColaborador)->first();
                            if (!$asigExistente) {
                                Asignatura::create([
                                    'id_asignatura'     => $idAsignaturaColaborador,
                                    'codigo_asignatura' => $codigoAsignaturaColab,
                                    'nombre_asignatura' => $nombreAsignaturaColaborador,
                                    'seccion'           => $numeroSeccionColab,
                                    'periodo'           => $periodoSeleccionado,
                                    'run_profesor'      => null, // El titular asignará su RUN al procesar su fila
                                    'id_carrera'        => !empty($idCarrera) ? $idCarrera : null
                                ]);
                            } else {
                                $datosUpdateAsig = ['periodo' => $periodoSeleccionado];
                                if (empty($asigExistente->id_carrera) && !empty($idCarrera)) {
                                    $datosUpdateAsig['id_carrera'] = $idCarrera;
                                }
                                $asigExistente->update($datosUpdateAsig);
                            }
                        }

                        // 2. Asegurar que el profesor tenga su carrera asignada si no la tenía
                        if ($existingProfesor && empty($existingProfesor->id_carrera) && !empty($idCarrera)) {
                            $existingProfesor->update(['id_carrera' => $idCarrera]);
                        }

                        try {
                            $limitesPeriodoColab = SemesterHelper::getLimitesPeriodo($periodoSeleccionado);
                            $colaboradorModel = ProfesorColaborador::updateOrCreate(
                                [
                                    'run_profesor_colaborador' => $run,
                                    'id_asignatura'           => !empty($idAsignaturaColaborador) ? $idAsignaturaColaborador : null,
                                    'fecha_inicio'            => $limitesPeriodoColab['inicio']->toDateString(),
                                ],
                                [
                                    'nombre_asignatura_temporal' => $nombreAsignaturaColaborador ?: null,
                                    'cantidad_inscritos'        => $inscritosColaborador,
                                    'fecha_termino'             => $limitesPeriodoColab['fin']->toDateString(),
                                    'estado'                    => 'activo',
                                ]
                            );

                            // 3. Registrar la planificación del colaborador en el espacio correspondiente
                            $horarioProfesorColab = trim($row[$colMap['horario_profesor']] ?? '');
                            if (!$tieneColumnaHorarioProfesor && empty($horarioProfesorColab)) {
                                $horarioProfesorColab = trim($row[$colMap['horario']] ?? '');
                            }
                            if (!empty($horarioProfesorColab)) {
                                $horarioProfesorColab = preg_replace('/[\x00-\x1F\x7F]/u', '', $horarioProfesorColab);
                                $horarioNormalizadoColab = preg_replace('/(?<!-)\s*([a-z]{2}:\s*)/i', ' - $1', $horarioProfesorColab);

                                preg_match_all('/([A-Za-z]{2})\s*\.\s*(\d{1,2})(?:\s*\/G:(\d+))?\s*\(([^)]+)\)/', $horarioNormalizadoColab, $matchesColabList, PREG_SET_ORDER);

                                // Recopilar primero todos los espacios resueltos
                                $slotsColabCandidatos = [];
                                $tieneEspaciosPracticos = false;

                                foreach ($matchesColabList as $mColab) {
                                    $diaC = strtoupper($mColab[1]);
                                    $moduloC = $mColab[2];
                                    $espacioNombreExcelC = trim($mColab[4]);
                                    $espacioNombreExcelC = EspacioAliasHelper::normalizar(
                                        $espacioNombreExcelC,
                                        $sedeActual ? $sedeActual->id_sede : ($prefijoTenantFiltro ?: null),
                                        [
                                            'carrera' => $carrera ? $carrera->nombre : '',
                                            'asignatura' => $nombreAsignaturaColaborador,
                                        ]
                                    );

                                    $espacioModelC = Espacio::withoutGlobalScope('tenant')
                                        ->where('id_espacio', $espacioNombreExcelC)
                                        ->first();

                                    if (!$espacioModelC && $prefijoTenantFiltro) {
                                        $espacioModelC = Espacio::withoutGlobalScope('tenant')
                                            ->where('id_espacio', $prefijoTenantFiltro . '-' . $espacioNombreExcelC)
                                            ->first();
                                    }

                                    if (!$espacioModelC) {
                                        $espacioModelC = Espacio::withoutGlobalScope('tenant')
                                            ->where('nombre_espacio', $espacioNombreExcelC)
                                            ->first();
                                    }

                                    if ($espacioModelC) {
                                        $esPractico = false;
                                        $tipoEsp = strtolower($espacioModelC->tipo_espacio ?? '');
                                        $nomEsp = strtolower($espacioModelC->nombre_espacio ?? '');
                                        if (str_contains($tipoEsp, 'taller') || str_contains($tipoEsp, 'lab') || str_contains($nomEsp, 'taller') || str_contains($nomEsp, 'lab') || str_contains($nomEsp, 'simulac') || str_contains($espacioModelC->id_espacio, '-211')) {
                                            $esPractico = true;
                                            $tieneEspaciosPracticos = true;
                                        }

                                        $slotsColabCandidatos[] = [
                                            'id_modulo' => $diaC . '.' . $moduloC,
                                            'id_espacio' => $espacioModelC->id_espacio,
                                            'es_practico' => $esPractico
                                        ];
                                    }
                                }

                                // Si el horario trae espacios prácticos (talleres/labs), el colaborador solo toma los prácticos
                                foreach ($slotsColabCandidatos as $slotC) {
                                    if ($tieneEspaciosPracticos && !$slotC['es_practico']) {
                                        continue; // Omitir salas de teoría para el docente de taller
                                    }

                                    $planColabExistente = \App\Models\PlanificacionProfesorColaborador::withoutGlobalScope('vigencia_activa')
                                        ->where('id_profesor_colaborador', $colaboradorModel->id)
                                        ->where('id_modulo', $slotC['id_modulo'])
                                        ->where('id_espacio', $slotC['id_espacio'])
                                        ->orderByDesc('id')
                                        ->first();

                                    if ($planColabExistente) {
                                        $planColabExistente->update([
                                            'fecha_inicio_vigencia' => $inicioVigenciaPeriodo,
                                            'fecha_fin_vigencia'    => $finVigenciaPeriodo,
                                        ]);
                                    } else {
                                        \App\Models\PlanificacionProfesorColaborador::create([
                                            'id_profesor_colaborador' => $colaboradorModel->id,
                                            'id_modulo'               => $slotC['id_modulo'],
                                            'id_espacio'              => $slotC['id_espacio'],
                                            'fecha_inicio_vigencia'   => $inicioVigenciaPeriodo,
                                            'fecha_fin_vigencia'      => $finVigenciaPeriodo,
                                        ]);
                                    }

                                    // Separar al titular solo en bloques prácticos asignados al colaborador.
                                    if (!empty($idAsignaturaColaborador) && $slotC['es_practico']) {
                                        $colaboradoresAsignados[$idAsignaturaColaborador][$slotC['id_modulo']][$slotC['id_espacio']] = true;

                                        // Si el titular se procesó antes y tomó este módulo/espacio de la misma asignatura en este mismo período, eliminar el duplicado activo
                                        Planificacion_Asignatura::where('id_asignatura', $idAsignaturaColaborador)
                                            ->where('id_modulo', $slotC['id_modulo'])
                                            ->where('id_espacio', $slotC['id_espacio'])
                                            ->whereHas('horario', function ($hq) use ($periodoSeleccionado) {
                                                $hq->where('periodo', $periodoSeleccionado);
                                            })
                                            ->delete();
                                    }
                                }
                            }
                        } catch (\Exception $e) {
                            Log::warning("Fila {$index}: no se pudo registrar colaborador RUN={$run}: " . $e->getMessage());
                        }

                        $skippedByColaborador++;
                        continue;
                    }

                    $idAsignatura = isset($row[$colMap['id_asignatura']]) ? trim($row[$colMap['id_asignatura']]) : '';
                    $codigoAsignatura = isset($row[$colMap['codigo_asignatura']]) ? trim($row[$colMap['codigo_asignatura']]) : '';
                    $nombreAsignatura = isset($row[$colMap['nombre_asignatura']]) ? preg_replace('/^[a-z]{2}:\s*/i', '', trim($row[$colMap['nombre_asignatura']])) : '';

                    $numeroSeccion = isset($row[$colMap['seccion']]) ? trim($row[$colMap['seccion']]) : '1';
                    $inscritos = isset($row[$colMap['inscritos']]) ? (int) $row[$colMap['inscritos']] : null;

                    // Validar que la sección sea un número de hasta 4 dígitos
                    if (!empty($numeroSeccion) && !preg_match('/^\d{1,4}$/', $numeroSeccion)) {
                        $errorMsg = 'Fila ' . ($index + 1) . ': Sección inválida - debe ser un número de 1 a 4 dígitos (valor: ' . $numeroSeccion . ')';
                        Log::warning($errorMsg);
                        $errors[] = $errorMsg;
                        continue;
                    }

                    // Si la sección está vacía, asignar un valor por defecto
                    if (empty($numeroSeccion)) {
                        $numeroSeccion = '1';
                    }

                    $existingAsignatura = Asignatura::withoutGlobalScope('tenant')->where('id_asignatura', $idAsignatura)->first();
                    if (!$existingAsignatura) {
                        $asignatura = Asignatura::create([
                            'id_asignatura' => $idAsignatura,
                            'codigo_asignatura' => $codigoAsignatura,
                            'nombre_asignatura' => $nombreAsignatura,
                            'seccion' => $numeroSeccion,
                            'periodo' => $periodoSeleccionado,
                            'run_profesor' => $run,
                            'id_carrera' => !empty($idCarrera) ? $idCarrera : null
                        ]);
                    } else {
                        // ACTUALIZACIÓN COMPLETA de la asignatura
                        $existingAsignatura->update([
                            'codigo_asignatura' => !empty($codigoAsignatura) ? $codigoAsignatura : $existingAsignatura->codigo_asignatura,
                            'nombre_asignatura' => !empty($nombreAsignatura) ? $nombreAsignatura : $existingAsignatura->nombre_asignatura,
                            'seccion' => $numeroSeccion,
                            'periodo' => $periodoSeleccionado,
                            'run_profesor' => $run,
                            'id_carrera' => !empty($idCarrera) ? $idCarrera : $existingAsignatura->id_carrera
                        ]);
                        $asignatura = $existingAsignatura;
                    }

                    $processedAsignaturasCount++;

                    $horarioProfesor = trim($row[$colMap['horario_profesor']] ?? '');
                    if (!$tieneColumnaHorarioProfesor && empty($horarioProfesor)) {
                        $horarioProfesor = trim($row[$colMap['horario']] ?? '');
                    }

                    $periodo = $periodoSeleccionado;

                    try {
                        $idHorario = 'HOR_' . $run . '_' . $periodo;

                        $existingHorario = Horario::withoutGlobalScope('tenant')->where('id_horario', $idHorario)->first();

                        if (!$existingHorario) {
                            $oldIdHorario = 'HOR_' . $run;
                            $oldHorario = Horario::withoutGlobalScope('tenant')->where('id_horario', $oldIdHorario)->first();

                            if ($oldHorario) {
                                // Eliminar horario antiguo sin sufijo de semestre para no mezclar semestres
                                Planificacion_Asignatura::withoutGlobalScope('vigencia_activa')
                                    ->where('id_horario', $oldIdHorario)
                                    ->delete();
                                $oldHorario->delete();
                            }
                        }

                        if ($existingHorario) {
                            $horario = $existingHorario;
                            // ACTUALIZACIÓN COMPLETA del horario
                            $horario->update([
                                'nombre' => 'Horario de ' . $name,
                                'periodo' => $periodo,
                                'run_profesor' => $run
                            ]);
                        } else {
                            $horario = new Horario();
                            $horario->id_horario = $idHorario;
                            $horario->nombre = 'Horario de ' . $name;
                            $horario->periodo = $periodo;
                            $horario->run_profesor = $run;

                            if (!$horario->save()) {
                                throw new \Exception('Error al guardar el horario');
                            }

                            if (!$horario->id_horario) {
                                throw new \Exception('El horario no se creó correctamente');
                            }
                        }

                        // Obtener prefijo del tenant UNA SOLA VEZ (fuera del loop de matches)
                        $prefijoTenantFiltro = '';
                        if (isset($tenant) && $tenant && $tenant->prefijo_espacios) {
                            $prefijoTenantFiltro = strtoupper(trim($tenant->prefijo_espacios));
                        }

                        if ($horario && $horario->id_horario && !empty($horarioProfesor)) {
                            // Limpieza de caracteres invisibles o raros
                            $horarioProfesor = preg_replace('/[\x00-\x1F\x7F]/u', '', $horarioProfesor);
                            $horarioProfesorNormalizado = preg_replace('/(?<!-)\s*([a-z]{2}:\s*)/i', ' - $1', $horarioProfesor);

                            // LOG DIAGNÓSTICO: primeras 3 filas para verificar qué se está leyendo de col U
                            if ($index <= 3) {
                                Log::info("[DIAG] Fila $index - Col U raw: '" . substr($horarioProfesor, 0, 200) . "'");
                                Log::info("[DIAG] Fila $index - Prefijo tenant: '" . $prefijoTenantFiltro . "'");
                            }

                            // Busca TODAS las coincidencias del patrón en todo el texto, sin importar cómo estén separadas.
                            // Formato esperado: DIA.MODULO/G:GRUPO (ESPACIO)
                            // El /G:GRUPO es opcional.
                            preg_match_all('/([A-Za-z]{2})\s*\.\s*(\d{1,2})(?:\s*\/G:(\d+))?\s*\(([^)]+)\)/', $horarioProfesorNormalizado, $matchesList, PREG_SET_ORDER);

                            if ($index <= 3 && !empty($matchesList)) {
                                Log::info("[DIAG] Fila $index - Matches encontrados: " . count($matchesList));
                                foreach ($matchesList as $mi => $mm) {
                                    Log::info("[DIAG]   Match $mi: DIA={$mm[1]}, MOD={$mm[2]}, ESP=" . (isset($mm[4]) ? $mm[4] : 'N/A'));
                                }
                            }

                            $planificacionesGuardadas = 0;

                            foreach ($matchesList as $matches) {
                                $dia = strtoupper($matches[1]);
                                $modulo = $matches[2];
                                $grupo = !empty($matches[3]) ? $matches[3] : '1';
                                $espacioNombreExcel = trim($matches[4]);
                                $espacioNombreExcel = EspacioAliasHelper::normalizar(
                                    $espacioNombreExcel,
                                    $sedeActual ? $sedeActual->id_sede : ($prefijoTenantFiltro ?: null),
                                    [
                                        'carrera' => $carrera ? $carrera->nombre : '',
                                        'asignatura' => $nombreAsignatura,
                                    ]
                                );

                                $espacioNombreUpper = strtoupper($espacioNombreExcel);

                                // Buscar el espacio:
                                // 1. Por ID exacto (ej: "TH-01")
                                // 2. Anteponiendo prefijo del tenant (ej: "TH-01")
                                // 3. Por nombre de espacio
                                $espacioModel = Espacio::withoutGlobalScope('tenant')
                                    ->where('id_espacio', $espacioNombreExcel)
                                    ->first();

                                if (!$espacioModel && $prefijoTenantFiltro) {
                                    $espacioModel = Espacio::withoutGlobalScope('tenant')
                                        ->where('id_espacio', $prefijoTenantFiltro . '-' . $espacioNombreExcel)
                                        ->first();
                                }

                                if (!$espacioModel) {
                                    $espacioModel = Espacio::withoutGlobalScope('tenant')
                                        ->where('nombre_espacio', $espacioNombreExcel)
                                        ->first();
                                }

                                if (!$espacioModel) {
                                    // Si el espacio trae prefijo explícito de OTRA sede (ej: LA-01 en tenant TH), saltar
                                    if ($prefijoTenantFiltro && str_contains($espacioNombreUpper, '-') && !str_starts_with($espacioNombreUpper, $prefijoTenantFiltro . '-')) {
                                        $espaciosOtrosTenants++;
                                        continue;
                                    }

                                    Log::warning("⚠ Fila $index: Espacio '{$espacioNombreExcel}' NO EXISTE en BD");
                                    $espaciosNoEncontrados++;

                                    if (!in_array($espacioNombreExcel, $espaciosFaltantes)) {
                                        $espaciosFaltantes[] = $espacioNombreExcel;
                                    }

                                    continue;
                                }

                                $espacioIdFinal = $espacioModel->id_espacio;

                                $idModulo = $dia . '.' . $modulo;

                                // Si este módulo y espacio ya fue asignado a un profesor colaborador de esta asignatura, omitir para el titular
                                if (isset($colaboradoresAsignados[$idAsignatura][$idModulo][$espacioIdFinal])) {
                                    Log::info("ℹ Fila $index: Omitiendo asignación de espacio {$espacioIdFinal} ({$idModulo}) para el titular RUN={$run} porque pertenece a un docente colaborador de la asignatura {$idAsignatura}.");
                                    continue;
                                }

                                // CREAR o REACTIVAR planificación (conservando historial de bloques previos)
                                try {
                                    $planExistente = Planificacion_Asignatura::withoutGlobalScope('vigencia_activa')
                                        ->where('id_asignatura', $idAsignatura)
                                        ->where('id_horario', $horario->id_horario)
                                        ->where('id_modulo', $idModulo)
                                        ->where('id_espacio', $espacioIdFinal)
                                        ->orderByDesc('id')
                                        ->first();

                                    if ($planExistente) {
                                        $planExistente->update([
                                            'fecha_inicio_vigencia' => $inicioVigenciaPeriodo,
                                            'fecha_fin_vigencia' => $finVigenciaPeriodo,
                                            'inscritos' => $inscritos,
                                            'data_load_id' => $dataLoad->id,
                                        ]);
                                        $processedHorariosCount++;
                                        $planificacionesGuardadas++;
                                    } else {
                                        $planificacion = new Planificacion_Asignatura();
                                        $planificacion->id_asignatura = $idAsignatura;
                                        $planificacion->id_horario = $horario->id_horario;
                                        $planificacion->id_modulo = $idModulo;
                                        $planificacion->id_espacio = $espacioIdFinal;
                                        $planificacion->inscritos = $inscritos;
                                        $planificacion->data_load_id = $dataLoad->id;
                                        $planificacion->fecha_inicio_vigencia = $inicioVigenciaPeriodo;
                                        $planificacion->fecha_fin_vigencia = $finVigenciaPeriodo;
                                        $planificacion->es_espacio_externo = $espacioModel->esEspacioExterno();
                                        $planificacion->save();

                                        $processedHorariosCount++;
                                        $planificacionesGuardadas++;
                                    }

                                    // Log de éxito: primeras 5 y cada 100
                                    if ($planificacionesGuardadas <= 5 || $planificacionesGuardadas % 100 == 0) {
                                        Log::info("✓ Planificación #{$planificacionesGuardadas}: asig={$idAsignatura}, hor={$horario->id_horario}, mod={$idModulo}, esp={$espacioIdFinal}");
                                    }
                                } catch (\Exception $planEx) {
                                    Log::error("✗ Fila $index - Error al crear planificación: " . $planEx->getMessage());
                                    Log::error("  → Datos: asig={$idAsignatura}, hor={$horario->id_horario}, mod={$idModulo}, esp={$espacioIdFinal}");
                                    // NO lanzar excepción, continuar con las demás
                                }
                            }

                            if ($planificacionesGuardadas == 0 && !empty($horarioProfesor)) {
                                Log::warning("⚠ Fila $index - Horario presente pero 0 planificaciones creadas. Raw: '$horarioProfesor'");
                            }
                        }
                    } catch (\Exception $e) {
                        $errorMsg = 'Fila ' . ($index + 1) . ': ' . $e->getMessage();
                        Log::error($errorMsg);
                        $errors[] = $errorMsg;
                        continue;
                    }
                } catch (\Exception $e) {
                    $errorMsg = 'Fila ' . ($index + 1) . ': ' . $e->getMessage();
                    Log::error($errorMsg);
                    $errors[] = $errorMsg;
                }
            }

            SemesterHelper::asegurarSeparacionSemestres($periodoSeleccionado, true);

            $dataLoad->update([
                'estado' => 'completado',
                'registros_cargados' => $processedUsersCount + $processedAsignaturasCount + $processedHorariosCount
            ]);

            // RESUMEN FINAL
            $totalPlanificaciones = Planificacion_Asignatura::whereHas('horario', function ($q) use ($periodoSeleccionado) {
                $q->where('periodo', $periodoSeleccionado);
            })->count();
            $totalEspaciosConClases = Planificacion_Asignatura::whereHas('horario', function ($q) use ($periodoSeleccionado) {
                $q->where('periodo', $periodoSeleccionado);
            })->distinct('id_espacio')->count('id_espacio');

            Log::info('═══════════════════════════════════════════════════════════');
            Log::info('✓ IMPORTACIÓN COMPLETADA - PERÍODO: ' . $periodoSeleccionado);
            Log::info('  → Filas rechazadas por sede incorrecta: ' . $skippedBySede);
            Log::info('  → Filas procesadas como profesor colaborador: ' . $skippedByColaborador);
            Log::info('  → Profesores procesados: ' . $processedUsersCount);
            Log::info('  → Asignaturas procesadas: ' . $processedAsignaturasCount);
            Log::info('  → Planificaciones creadas: ' . $processedHorariosCount);
            Log::info('  → Planificaciones en BD (período): ' . $totalPlanificaciones);
            Log::info('  → Espacios con clases: ' . $totalEspaciosConClases);
            Log::info('  → Espacios otros tenants (saltados): ' . $espaciosOtrosTenants);
            Log::info('  → Espacios no encontrados en BD: ' . $espaciosNoEncontrados);

            if (!empty($espaciosFaltantes)) {
                Log::warning('⚠ ESPACIOS FALTANTES QUE DEBES CREAR MANUALMENTE:');
                foreach ($espaciosFaltantes as $espFaltante) {
                    Log::warning('  - ' . $espFaltante);
                }
            }

            Log::info('  → Errores encontrados: ' . count($errors));
            Log::info('═══════════════════════════════════════════════════════════');

            $message = 'Archivo procesado exitosamente. Se procesaron ' . $processedUsersCount . ' profesores, '
                . $processedAsignaturasCount . ' asignaturas y ' . $processedHorariosCount . ' planificaciones. '
                . 'Total en BD: ' . $totalPlanificaciones . ' planificaciones en ' . $totalEspaciosConClases . ' espacios.';
            if (!empty($errors)) {
                $message .= ' Se encontraron ' . count($errors) . ' errores.';
            }

            return response()->json([
                'message' => $message,
                'data' => [
                    'nombre_archivo' => $dataLoad,
                    'profesores_procesados' => $processedUsersCount,
                    'asignaturas_procesadas' => $processedAsignaturasCount,
                    'horarios_procesados' => $processedHorariosCount,
                    'filas_omitidas' => $skippedRows,
                    'errores' => $errors
                ]
            ]);
        } catch (\Throwable $e) {
            Log::error('Error en carga masiva: ' . $e->getMessage(), ['file' => $e->getFile(), 'line' => $e->getLine()]);
            if (isset($dataLoad) && $dataLoad) {
                try { $dataLoad->update(['estado' => 'error']); } catch (\Throwable $inner) {}
            }
            return response()->json([
                'message' => 'Error al procesar el archivo: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy(DataLoad $dataLoad)
    {
        try {
            if ($dataLoad->ruta_archivo && Storage::disk('public')->exists($dataLoad->ruta_archivo)) {
                Storage::disk('public')->delete($dataLoad->ruta_archivo);
            }

            $dataLoad->delete();

            return redirect()
                ->route('data.index')
                ->with('success', 'Registro de carga y su información asociada fueron eliminados exitosamente.');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Error al eliminar el registro de carga.']);
        }
    }

    public function detalleJson($id)
    {
        $dataLoad = DataLoad::with('user')->findOrFail($id);

        // Calcula el tamaño del archivo en MB
        $tamano = null;
        if ($dataLoad->ruta_archivo && \Storage::disk('public')->exists($dataLoad->ruta_archivo)) {
            $tamano = round(\Storage::disk('public')->size($dataLoad->ruta_archivo) / 1024 / 1024, 1) . ' MB';
        }

        return response()->json([
            'id' => $dataLoad->id,
            'nombre_archivo' => $dataLoad->nombre_archivo,
            'estado' => $dataLoad->estado,
            'registros_cargados' => $dataLoad->registros_cargados,
            'tamano' => $tamano,
            'tipo_carga' => $dataLoad->tipo_carga,
            'ruta_archivo' => $dataLoad->ruta_archivo,
            'usuario_nombre' => $dataLoad->user->name ?? '',
            'usuario_run' => $dataLoad->user->run ?? '',
            'fecha_carga' => $dataLoad->created_at ? $dataLoad->created_at->format('d/m/Y H:i:s') : '',
            'fecha_actualizacion' => $dataLoad->updated_at ? $dataLoad->updated_at->format('d/m/Y H:i:s') : '',
            'url_descarga' => $dataLoad->ruta_archivo ? \Storage::disk('public')->url($dataLoad->ruta_archivo) : '',
        ]);
    }

    public function download($id)
    {
        $dataLoad = DataLoad::findOrFail($id);

        if (!$dataLoad->ruta_archivo || !Storage::disk('public')->exists($dataLoad->ruta_archivo)) {
            return back()->withErrors(['error' => 'El archivo no existe o ha sido eliminado.']);
        }

        return Storage::disk('public')->download($dataLoad->ruta_archivo, $dataLoad->nombre_archivo);
    }

    public function progress($id)
    {
        try {
            $dataLoad = DataLoad::findOrFail($id);

            return response()->json([
                'estado' => $dataLoad->estado,
                'registros_cargados' => $dataLoad->registros_cargados,
                'mensaje' => $this->getEstadoMensaje($dataLoad->estado)
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'estado' => 'error',
                'mensaje' => 'Error al obtener el progreso'
            ], 500);
        }
    }

    private function getEstadoMensaje($estado)
    {
        switch ($estado) {
            case 'pendiente':
                return 'Archivo en cola de procesamiento';
            case 'procesando':
                return 'Procesando archivo...';
            case 'completado':
                return 'Proceso finalizado';
            case 'error':
                return 'Error en el procesamiento';
            default:
                return 'Estado desconocido';
        }
    }

    public function limpiarPeriodo(Request $request)
    {
        $request->validate([
            'semestre_selector' => 'required|in:1,2'
        ]);

        $semestreSeleccionado = $request->input('semestre_selector');
        $anioActual = \App\Helpers\SemesterHelper::getCurrentAcademicYear();
        $periodoSeleccionado = $anioActual . '-' . $semestreSeleccionado;

        try {
            // Eliminar planificaciones del periodo
            $horariosDelPeriodo = Horario::where('periodo', $periodoSeleccionado)->pluck('id_horario');
            $planificacionesEliminadas = Planificacion_Asignatura::whereIn('id_horario', $horariosDelPeriodo)->delete();

            // Eliminar los horarios asociados a ese periodo
            $horariosEliminados = Horario::where('periodo', $periodoSeleccionado)->delete();

            Log::info("Limpieza manual del periodo {$periodoSeleccionado}: {$planificacionesEliminadas} planificaciones y {$horariosEliminados} horarios eliminados.");

            return response()->json([
                'success' => true,
                'message' => "Se han eliminado {$planificacionesEliminadas} planificaciones y {$horariosEliminados} horarios del periodo {$periodoSeleccionado} exitosamente."
            ]);
        } catch (\Exception $e) {
            Log::error('Error al limpiar periodo: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error al limpiar los datos del periodo: ' . $e->getMessage()
            ], 500);
        }
    }
}
