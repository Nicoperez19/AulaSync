<?php

namespace App\Http\Controllers;

use Spatie\Permission\Models\Permission;

use Illuminate\Http\Request;

class PermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('permisos.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'name' => ['required', 'string', 'max:255'],
            ]);

            $permission = Permission::create([
                'name' => $validatedData['name'],
            ]);

            return redirect()->route('permissions.index')->with('success', 'Permiso creado exitosamente.');

        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Hubo un problema al crear el permiso. Por favor, intente nuevamente.'])->withInput();
        }
    }



    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $permission = Permission::findOrFail($id);
        return view('permisos.index', compact('permission'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $validatedData = $request->validate([
                'name' => ['required', 'string', 'max:255'],
            ]);

            $permission = Permission::findOrFail($id);
            $permission->name = $validatedData['name'];
            $permission->save();

            return redirect()->route('permissions.index')->with('success', 'Permiso actualizado exitosamente.');

        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Hubo un problema al actualizar el permiso. Por favor, intente nuevamente.'])->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $permission = Permission::findOrFail($id);
            $permission->delete();
            
            // Verificar si la petición espera JSON
            if (request()->expectsJson() || request()->header('Accept') === 'application/json') {
                return response()->json([
                    'success' => true, 
                    'message' => 'Permiso eliminado exitosamente.'
                ]);
            }
            
            return redirect()->route('permissions.index')->with('success', 'Permiso eliminado exitosamente.');

        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            if (request()->expectsJson() || request()->header('Accept') === 'application/json') {
                return response()->json(['success' => false, 'message' => 'Permiso no encontrado.'], 404);
            }
            return redirect()->route('permissions.index')->with('error', 'Permiso no encontrado.');
        } catch (\Exception $e) {
            if (request()->expectsJson() || request()->header('Accept') === 'application/json') {
                return response()->json(['success' => false, 'message' => 'Error al borrar el permiso: ' . $e->getMessage()], 500);
            }
            return redirect()->route('permissions.index')->with('error', 'Error al borrar el permiso: ' . $e->getMessage());
        }
    }
}
