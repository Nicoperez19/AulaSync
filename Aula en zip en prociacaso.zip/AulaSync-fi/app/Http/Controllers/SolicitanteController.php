<?php

namespace App\Http\Controllers;

use App\Models\Espacio;
use App\Models\Planificacion_Asignatura;
use App\Models\Reserva;
use App\Models\Solicitante;
use App\Models\Tenant;
use App\Models\Visitante;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

use App\Traits\RunNormalizer;
use App\Helpers\ModulosHelper;

/**
 * Controlador para manejar operaciones de solicitantes
 *
 * Los solicitantes son usuarios externos que pueden reservar espacios
 * pero no son profesores registrados en el sistema.
 */
class SolicitanteController extends Controller
{
    use RunNormalizer;

    /**
     * Verificar si un solicitante existe en la base de datos
     */
    public function verificarSolicitante($run)
    {
        // Obtener y configurar el tenant
        $tenantId = tenant_id();
        if (!$tenantId) {
            return response()->json([
                'verificado' => false,
                'mensaje' => 'No se encontró contexto de tenant'
            ], 400);
        }

        $tenant = Tenant::find($tenantId);
        if (!$tenant) {
            return response()->json([
                'verificado' => false,
                'mensaje' => 'Tenant no encontrado'
            ], 400);
        }

        // CONFIGURAR EXPLÍCITAMENTE LA CONEXIÓN TENANT
        Config::set('database.connections.tenant.database', $tenant->database);
        DB::purge('tenant');

        // Normalizar RUN
        $run = $this->normalizeRun($run);

        try {
            $solicitante = Solicitante::on('tenant')
                ->where('run_solicitante', $run)
                ->where('activo', true)
                ->first();


            if ($solicitante) {
                return response()->json([
                    'verificado' => true,
                    'tipo_usuario' => 'solicitante_registrado',
                    'solicitante' => [
                        'run_solicitante' => $solicitante->run_solicitante,
                        'nombre' => $solicitante->nombre,
                        'correo' => $solicitante->correo,
                        'telefono' => $solicitante->telefono,
                        'tipo_solicitante' => $solicitante->tipo_solicitante
                    ],
                    'mensaje' => 'Solicitante verificado correctamente'
                ]);
            }

            // Si no está registrado, retornar información para registro
            return response()->json([
                'verificado' => false,
                'tipo_usuario' => 'solicitante_nuevo',
                'run_escaneado' => $run,
                'mensaje' => 'Solicitante no registrado. Se requiere registro previo.'
            ]);
        } catch (\Exception $e) {
            Log::error('Error al verificar solicitante: ' . $e->getMessage());
            return response()->json([
                'verificado' => false,
                'mensaje' => 'Error al verificar solicitante: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Registrar un nuevo solicitante
     */
    public function registrarSolicitante(Request $request)
    {
        // Obtener y configurar el tenant
        $tenantId = tenant_id();
        if (!$tenantId) {
            return response()->json([
                'success' => false,
                'mensaje' => 'No se encontró contexto de tenant'
            ], 400);
        }

        $tenant = Tenant::find($tenantId);
        if (!$tenant) {
            return response()->json([
                'success' => false,
                'mensaje' => 'Tenant no encontrado'
            ], 400);
        }

        // CONFIGURAR EXPLÍCITAMENTE LA CONEXIÓN TENANT
        Config::set('database.connections.tenant.database', $tenant->database);
        DB::purge('tenant');

        try {
            $request->validate([
                'run_solicitante' => 'required|string',
                'nombre' => 'required|string|max:255',
                'correo' => 'required|email',
                'telefono' => 'required|string|max:20',
                'tipo_solicitante' => 'required|in:estudiante,personal,visitante,otro'
            ]);

            // Normalizar RUN
            $runNormalizado = $this->normalizeRun($request->run_solicitante);

            $solicitante = Solicitante::on('tenant')->updateOrCreate(
                ['run_solicitante' => $runNormalizado],
                [
                    'nombre' => $request->nombre,
                    'correo' => $request->correo,
                    'telefono' => $request->telefono,
                    'tipo_solicitante' => $request->tipo_solicitante,
                    'activo' => true,
                    'fecha_registro' => now()
                ]
            );


            // Registrar también como visitante para que aparezca en el mantenedor
            try {
                Visitante::create([
                    'run_solicitante' => $request->run_solicitante,
                    'nombre' => $request->nombre,
                    'correo' => $request->correo,
                    'telefono' => $request->telefono,
                    'tipo_solicitante' => $request->tipo_solicitante,
                    'activo' => true,
                    'fecha_registro' => now(),
                ]);
            } catch (\Exception $e) {
                // Si falla al crear el visitante, continuamos igual porque ya tenemos el solicitante
                Log::warning('No se pudo registrar como visitante: ' . $e->getMessage());
            }



            return response()->json([
                'success' => true,
                'mensaje' => 'Solicitante registrado exitosamente',
                'solicitante' => [
                    'run_solicitante' => $solicitante->run_solicitante,
                    'nombre' => $solicitante->nombre,
                    'correo' => $solicitante->correo,
                    'telefono' => $solicitante->telefono,
                    'tipo_solicitante' => $solicitante->tipo_solicitante,
                    'institucion_origen' => $solicitante->institucion_origen
                ]
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'mensaje' => 'Error de validación: ' . $e->getMessage(),
                'errores' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error al registrar solicitante: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'mensaje' => 'Error al registrar solicitante: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Crear una reserva para un solicitante
     */
    public function crearReservaSolicitante(Request $request)
    {


        // Obtener el tenant del contexto actual
        $tenantId = tenant_id();
        if (!$tenantId) {
            return response()->json([
                'success' => false,
                'mensaje' => 'No se encontró contexto de tenant'
            ], 400);
        }

        $tenant = Tenant::find($tenantId);
        if (!$tenant) {
            return response()->json([
                'success' => false,
                'mensaje' => 'Tenant no encontrado'
            ], 400);
        }

        // CONFIGURAR EXPLÍCITAMENTE LA CONEXIÓN TENANT
        Config::set('database.connections.tenant.database', $tenant->database);
        Config::set('database.connections.tenant.host', $tenant->host ?? config('database.connections.mysql.host'));
        DB::purge('tenant');



        try {
            // VERIFICAR QUE LA CONEXIÓN TENANT ESTÁ CONFIGURADA
            $tenantConfig = config('database.connections.tenant');


            // Validar datos básicos
            $request->validate([
                'run_solicitante' => 'required|string',
                'id_espacio' => 'required|string',
                'modulos' => 'required|integer|min:1|max:15'
            ]);

            // Normalizar id_espacio usando la lógica del tenant actual
            $idEspacio = $request->id_espacio;
            if (!empty($idEspacio)) {
                $idEspacio = strtoupper(trim(str_replace(' ', '', $idEspacio)));
                $tenant = Tenant::find(tenant_id());
                if ($tenant) {
                    $prefix = strtoupper($tenant->prefijo_espacios ?: $tenant->domain);
                    $normalizedInput = str_replace('-', '', $idEspacio);
                    if (strpos($normalizedInput, $prefix) === 0) {
                        $normalizedInput = substr($normalizedInput, strlen($prefix));
                    }
                    $idEspacio = $prefix . '-' . $normalizedInput;
                }
                $request->merge(['id_espacio' => $idEspacio]);
            }

            $ahora = Carbon::now();
            $horaActual = $ahora->format('H:i:s');
            $fechaActual = $ahora->toDateString();

            // Normalizar RUN
            $runNormalizado = $this->normalizeRun($request->run_solicitante);

            // Verificar que el solicitante existe y está activo (búsqueda en BD tenant)
            $solicitante = Solicitante::on('tenant')
                ->where('run_solicitante', $runNormalizado)
                ->where('activo', true)
                ->first();


            if (!$solicitante) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Solicitante no encontrado o inactivo'
                ], 404);
            }

            // Verificar que el espacio existe y está disponible (búsqueda en BD tenant)
            $espacio = Espacio::on('tenant')->where('id_espacio', $request->id_espacio)->first();
            if (!$espacio) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Espacio no encontrado'
                ], 404);
            }

            if ($espacio->estado === 'Ocupado') {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'El espacio está ocupado actualmente'
                ], 400);
            }

            // NOTA: Se ha relajado la restricción de reservas vigentes para permitir múltiples reservas
            // como fue solicitado por el usuario.
            /*
            $reservaActiva = Reserva::on('tenant')
                ->where('run_solicitante', $runNormalizado)
                ->where('estado', 'activa')
                ->where('fecha_reserva', $fechaActual)  // Hoy
                ->where('hora_salida', '>', $horaActual)  // Aún no ha terminado
                ->first();

            if ($reservaActiva) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Ya tienes una reserva activa en este horario. Debes finalizarla antes de solicitar una nueva.'
                ], 400);
            }
            */


            // Validar módulos consecutivos disponibles
            $modulosSolicitados = $request->modulos;
            $diasSemana = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
            $diaActual = $diasSemana[$ahora->dayOfWeek];

            $codigosDias = [
                'lunes' => 'LU', 'martes' => 'MA', 'miercoles' => 'MI',
                'jueves' => 'JU', 'viernes' => 'VI', 'sabado' => 'SA', 'domingo' => 'DO'
            ];

            $codigoDia = $codigosDias[$diaActual] ?? 'LU';

            // Determinar módulo actual
            $moduloActual = $this->determinarModuloActual($horaActual, $diaActual);

            $usarHoraActual = false;
            if (!$moduloActual) {
                // Verificar si ya terminó el día académico para el día actual
                $ultimoModulo = \App\Models\Modulo::on('tenant')
                    ->where('id_modulo', 'like', $codigoDia . '.%')
                    ->orderBy('hora_termino', 'desc')
                    ->first();
                
                if ($ultimoModulo && $horaActual >= $ultimoModulo->hora_termino) {
                    return response()->json([
                        'success' => false,
                        'mensaje' => 'El horario académico para el día de hoy ha finalizado. No es posible crear nuevas reservas espontáneas.'
                    ], 400);
                }

                // Si estamos antes del primer módulo, empezar desde el módulo 1
                $primerModulo = \App\Models\Modulo::on('tenant')
                    ->where('id_modulo', 'like', $codigoDia . '.%')
                    ->orderBy('hora_inicio', 'asc')
                    ->first();
                
                if ($primerModulo && $horaActual < $primerModulo->hora_inicio) {
                    $moduloActual = 1;
                    $usarHoraActual = false; // Empezar en el horario oficial del módulo 1
                } else {
                    // Probablemente estamos en un recreo, intentar buscar el siguiente módulo del día
                    $siguienteModulo = \App\Models\Modulo::on('tenant')
                        ->where('id_modulo', 'like', $codigoDia . '.%')
                        ->where('hora_inicio', '>', $horaActual)
                        ->orderBy('hora_inicio', 'asc')
                        ->first();
                    
                    if ($siguienteModulo) {
                        // Extraer el número del módulo (ej: "LU.2" -> 2)
                        $partes = explode('.', $siguienteModulo->id_modulo);
                        $moduloActual = isset($partes[1]) ? (int)$partes[1] : 1;
                        $usarHoraActual = false;
                    } else {
                        // Fallback de seguridad
                        $moduloActual = 1;
                        $usarHoraActual = true;
                    }
                }
            }

            // Verificar módulos consecutivos disponibles (incluyendo reservas activas)
            $planificaciones = Planificacion_Asignatura::on('tenant')
                ->where('id_espacio', $request->id_espacio)
                ->where('id_modulo', 'like', $codigoDia . '.%')
                ->pluck('id_modulo')
                ->toArray();

            // Obtener reservas activas para este espacio en este día
            $reservasActivas = Reserva::on('tenant')
                ->where('id_espacio', $request->id_espacio)
                ->where('fecha_reserva', $fechaActual)
                ->where('estado', 'activa')
                ->get();

            // Crear array de módulos ocupados por reservas
            $modulosOcupadosPorReservas = [];
            foreach ($reservasActivas as $reserva) {
                $horaInicio = $reserva->hora;
                $horaFin = $reserva->hora_salida;

                // Determinar qué módulos cubre esta reserva
                for ($i = 1; $i <= 15; $i++) {
                    $moduloCodigo = $codigoDia . '.' . $i;
                    $horarioModulo = $this->obtenerHorarioModulo($i, $diaActual);

                    if ($horarioModulo &&
                            $horaInicio <= $horarioModulo['fin'] &&
                            $horaFin >= $horarioModulo['inicio']) {
                        $modulosOcupadosPorReservas[] = $moduloCodigo;
                    }
                }
            }

            // Combinar planificaciones y reservas activas
            $modulosOcupados = array_merge($planificaciones, $modulosOcupadosPorReservas);
            $modulosOcupados = array_unique($modulosOcupados);

            $modulosDisponibles = 0;
            $modulosDisponiblesList = [];
            $proximaClase = null;

            for ($i = $moduloActual; $i <= 15; $i++) {
                $moduloCodigo = $codigoDia . '.' . $i;

                $ocupadoPorReservaActiva = in_array($moduloCodigo, $modulosOcupadosPorReservas);
                $ocupadoPorPlanificacion = in_array($moduloCodigo, $planificaciones);

                if ($ocupadoPorReservaActiva || ($i > $moduloActual && $ocupadoPorPlanificacion)) {
                    // Encontrar información de la próxima clase si es una planificación
                    if ($ocupadoPorPlanificacion) {
                        $proximaClase = $this->obtenerInfoProximaClase($moduloCodigo, $request->id_espacio);
                    }
                    break;
                }

                $modulosDisponiblesList[] = $i;
                $modulosDisponibles++;

                if ($modulosDisponibles >= $modulosSolicitados) {
                    break;
                }
            }

            if ($modulosDisponibles < $modulosSolicitados) {
                $mensaje = 'No hay suficientes módulos consecutivos disponibles.';
                if ($proximaClase) {
                    $mensaje .= " Próxima clase: {$proximaClase['asignatura']} (Módulo {$proximaClase['modulo']})";
                }
                return response()->json([
                    'success' => false,
                    'mensaje' => $mensaje
                ], 400);
            }

            // Obtener horarios desde la tabla Modulo usando id_modulo
            // Construir id_modulo (ej: "JU.7")
            $prefijosDias = ['DO', 'LU', 'MA', 'MI', 'JU', 'VI', 'SA'];
            $diasArray = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
            $indexDia = array_search($diaActual, $diasArray);
            $prefijo = $indexDia !== false ? $prefijosDias[$indexDia] : 'LU';

            $idModuloInicio = $prefijo . '.' . $moduloActual;
            $idModuloFin = $prefijo . '.' . ($moduloActual + $modulosSolicitados - 1);

            $moduloInicio = \App\Models\Modulo::on('tenant')->where('id_modulo', $idModuloInicio)->first();
            $moduloFin = \App\Models\Modulo::on('tenant')->where('id_modulo', $idModuloFin)->first();

            $horaInicio = ($moduloInicio && !$usarHoraActual) ? $moduloInicio->hora_inicio : $horaActual;

            // Si no hay módulo final, calcular una hora por defecto (1.5 horas por módulo)
            if ($moduloFin) {
                $horaFin = $moduloFin->hora_termino;
            } else {
                // Calcular hora fin aproximada: 1.5 horas por módulo solicitado
                $duracionMinutos = $modulosSolicitados * 90;  // 1.5 horas = 90 minutos por módulo
                $horaFin = Carbon::createFromFormat('H:i:s', $horaInicio)
                    ->addMinutes($duracionMinutos)
                    ->format('H:i:s');
            }

            // Verificar que no haya reservas simultáneas en el tiempo
            $reservasSimultaneas = Reserva::on('tenant')
                ->where('run_solicitante', $request->run_solicitante)
                ->where('estado', 'activa')
                ->where('fecha_reserva', $fechaActual)  // Filtrar por fecha
                ->where(function ($query) use ($horaInicio, $horaFin) {
                    // Verificar si hay solapamiento de horarios
                    $query->where(function ($q) use ($horaInicio, $horaFin) {
                        // La nueva reserva empieza antes y termina durante una reserva existente
                        $q
                            ->where('hora', '<=', $horaInicio)
                            ->where('hora_salida', '>', $horaInicio);
                    })->orWhere(function ($q) use ($horaInicio, $horaFin) {
                        // La nueva reserva empieza durante una reserva existente
                        $q
                            ->where('hora', '>=', $horaInicio)
                            ->where('hora', '<', $horaFin);
                    })->orWhere(function ($q) use ($horaInicio, $horaFin) {
                        // La nueva reserva contiene completamente una reserva existente
                        $q
                            ->where('hora', '>=', $horaInicio)
                            ->where('hora_salida', '<=', $horaFin);
                    });
                })
                ->first();

            if ($reservasSimultaneas) {
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Ya tienes una reserva activa en ese horario.'
                ], 400);
            }

            // Generar ID único para la reserva
            $idReserva = Reserva::generarIdUnico();

            // INSERTAR DIRECTAMENTE con Query Builder para garantizar que va a la BD tenant
            $insertado = DB::connection('tenant')->table('reservas')->insert([
                'id_reserva' => $idReserva,
                'hora' => $horaInicio,
                'fecha_reserva' => $fechaActual,
                'id_espacio' => $request->id_espacio,
                'run_solicitante' => $runNormalizado,
                'run_profesor' => null,

                'tipo_reserva' => 'espontanea',
                'estado' => 'activa',
                'created_at' => $ahora,
                'updated_at' => $ahora
            ]);

            // Actualizar estado del espacio a 'Ocupado' inmediatamente
            // para evitar que ActualizarEstadoEspacios tenga que esperar 15 minutos
            if ($insertado) {
                DB::connection('tenant')
                    ->table('espacios')
                    ->where('id_espacio', $request->id_espacio)
                    ->update([
                        'estado' => 'Ocupado',
                        'updated_at' => $ahora
                    ]);


            }



            // Verificar que la reserva se guardó usando Query Builder
            $reservaVerificacion = DB::connection('tenant')
                ->table('reservas')
                ->where('id_reserva', $idReserva)
                ->first();

            if (!$reservaVerificacion) {
                Log::error('❌ ERROR CRÍTICO: Reserva NO se guardó en BD tenant', [
                    'id_reserva' => $idReserva,
                    'run_solicitante' => $request->run_solicitante,
                    'insertado_resultado' => $insertado
                ]);
                return response()->json([
                    'success' => false,
                    'mensaje' => 'Error al guardar la reserva en la base de datos'
                ], 500);
            }



            // Actualizar estado del espacio usando Query Builder también
            DB::connection('tenant')
                ->table('espacios')
                ->where('id_espacio', $request->id_espacio)
                ->update(['estado' => 'Ocupado', 'updated_at' => $ahora]);

            // Enviar comprobante de reserva por correo
            $reservaModel = Reserva::on('tenant')->where('id_reserva', $idReserva)->first();
            if ($reservaModel) {
                app(\App\Services\ReservaService::class)->enviarCorreoReserva($reservaModel, $solicitante->correo ?? null);
            }

            return response()->json([
                'success' => true,
                'mensaje' => 'Reserva creada exitosamente',
                'modulos' => $modulosSolicitados,
                'reserva' => [
                    'id' => $idReserva,
                    'hora' => $horaInicio,
                    'fecha' => $fechaActual,
                    'espacio' => $espacio->nombre_espacio,
                    'solicitante' => $solicitante->nombre,
                    'modulos_reservados' => $modulosSolicitados
                ]
            ]);
        } catch (ValidationException $e) {
            // La ValidationException ocurre antes de la transacción, no necesita rollBack
            Log::error('Error de validación al crear reserva de solicitante: ' . json_encode($e->errors()));
            return response()->json([
                'success' => false,
                'mensaje' => 'Error de validación en los datos enviados',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            // Los errores en la transacción se manejan automáticamente (auto-rollback)
            Log::error('Error al crear reserva de solicitante: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'mensaje' => 'Error al crear reserva: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Determinar el módulo actual según la hora
     */
    private function determinarModuloActual($horaActual, $diaActual)
    {
        return ModulosHelper::obtenerModuloActual($horaActual, $diaActual);
    }

    /**
     * Obtiene el horario de un módulo específico
     */
    private function obtenerHorarioModulo($modulo, $diaActual)
    {
        // Prefijo del día
        $prefijosDias = ['DO', 'LU', 'MA', 'MI', 'JU', 'VI', 'SA'];
        $diasArray = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
        $indexDia = array_search($diaActual, $diasArray);
        $prefijo = $indexDia !== false ? $prefijosDias[$indexDia] : 'LU';

        $idModulo = $prefijo . '.' . $modulo;
        // Usar explícitamente la conexión 'tenant'
        $moduloData = \App\Models\Modulo::on('tenant')->where('id_modulo', $idModulo)->first();

        if (!$moduloData) {
            return null;
        }

        return [
            'inicio' => $moduloData->hora_inicio,
            'fin' => $moduloData->hora_termino
        ];
    }

    /**
     * Obtiene información de la próxima clase programada
     */
    private function obtenerInfoProximaClase($moduloCodigo, $espacioId)
    {
        // Usar explícitamente la conexión 'tenant'
        $planificacion = Planificacion_Asignatura::on('tenant')
            ->with(['asignatura', 'horario.profesor', 'modulo'])
            ->where('id_espacio', $espacioId)
            ->where('id_modulo', $moduloCodigo)
            ->first();

        if ($planificacion) {
            return [
                'modulo' => $moduloCodigo,
                'asignatura' => $planificacion->asignatura->nombre_asignatura ?? 'Sin asignatura',
                'profesor' => $planificacion->horario->profesor->name ?? 'No especificado',
                'hora_inicio' => $planificacion->modulo->hora_inicio ?? '',
                'hora_termino' => $planificacion->modulo->hora_termino ?? ''
            ];
        }

        return null;
    }

    /**
     * Verificar si un RUN existe en la tabla solicitantes
     */
    public function verificarExistencia($run)
    {
        try {
            $this->establecerContextoTenant();

            $runLimpio = preg_replace('/[^0-9]/', '', $run);

            $existe = Solicitante::on('tenant')
                ->where('run_solicitante', $run)
                ->orWhere('run_solicitante', $runLimpio)
                ->exists();

            return response()->json([
                'existe' => $existe
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'existe' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Establece el contexto del tenant desde el request
     */
    private function establecerContextoTenant()
    {
        try {
            $tenantId = tenant_id() ?? null;



            if (!$tenantId) {
                // Si no hay tenant establecido, buscarlo por dominio
                $host = request()->getHost();
                $tenant = Tenant::where('domain', $host)
                    ->orWhere('domain', 'LIKE', '%' . $host . '%')
                    ->first();

                if ($tenant) {
                    $tenantId = $tenant->id;
                    // CONFIGURAR EXPLÍCITAMENTE LA CONEXIÓN TENANT
                    Config::set('database.connections.tenant.database', $tenant->database);
                    DB::purge('tenant');

                } else {

                    return;
                }
            } else {
                // Si el tenant ya estaba establecido, asegurar que la conexión está bien configurada
                $tenant = Tenant::find($tenantId);
                if ($tenant) {
                    // CONFIGURAR EXPLÍCITAMENTE LA CONEXIÓN TENANT
                    Config::set('database.connections.tenant.database', $tenant->database);
                    DB::purge('tenant');


                    // VERIFICACIÓN DE CONEXIÓN
                    try {
                        DB::connection('tenant')->getPdo();

                    } catch (\Exception $e) {
                        Log::error('Error al verificar conexión tenant: ' . $e->getMessage());
                        throw $e;
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('Error en establecerContextoTenant', [
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
}
