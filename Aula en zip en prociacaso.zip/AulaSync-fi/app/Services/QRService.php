<?php

namespace App\Services;

use App\Models\Espacio;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Illuminate\Support\Facades\Storage;

class QRService
{
    public function generateSpaceQR(Espacio $espacio, int $size = 300): string
    {
        // Generamos una URL única para el espacio
        $url = route('spaces.show', ['space' => $espacio->id_espacio]);
        
        $qrCode = new QrCode($url);
        $writer = new PngWriter();
        $result = $writer->write($qrCode);

        // Guardamos el código QR en el almacenamiento
        $path = 'qrcodes/qr_' . $espacio->id_espacio . '.png';
        Storage::put('public/' . $path, $result->getString());

        return $path;
    }

    public function generateQR(string $data, int $size = 300): string
    {
        $qrCode = new QrCode($data);
        $writer = new PngWriter();
        $result = $writer->write($qrCode);

        // Guardamos el código QR en el almacenamiento
        $path = 'qrcodes/qr_' . $data . '.png';
        Storage::put('public/' . $path, $result->getString());

        return $path;
    }

    public function generateQRForEspacio(string $espacioId): string
    {
        // Generamos el QR con el ID del espacio directamente
        return $this->generateQR($espacioId);
    }
} 