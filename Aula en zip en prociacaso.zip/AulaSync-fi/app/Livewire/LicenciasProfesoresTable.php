<?php

namespace App\Livewire;

use App\Models\LicenciaProfesor;
use App\Models\Profesor;
use App\Services\LicenciaRecuperacionService;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Auth;

class LicenciasProfesoresTable extends Component
{
    use WithPagination;

    public $search = '';
    public $estado = '';
    public $sortField = 'fecha_inicio';
    public $sortDirection = 'desc';
    
    // Propiedades para el modal de crear/editar
    public $showModal = false;
    public $editMode = false;
    public $licenciaId;
    public $run_profesor = '';
    public $profesorNombre = '';
    public $fecha_inicio = '';
    public $fecha_fin = '';
    public $motivo = '';
    public $observaciones = '';
    public $genera_recuperacion = true;

    protected $queryString = ['search', 'estado'];

    protected function rules()
    {
        return [
            'run_profesor' => 'required|exists:tenant.profesors,run_profesor',
            'fecha_inicio' => 'required|date',
            'fecha_fin' => 'required|date|after_or_equal:fecha_inicio',
            'motivo' => 'nullable|string|max:255',
            'observaciones' => 'nullable|string',
            'genera_recuperacion' => 'boolean',
        ];
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingEstado()
    {
        $this->resetPage();
    }

    public function getProfesoresFiltradosProperty()
    {
        if (empty($this->run_profesor) || strlen($this->run_profesor) < 2 || !empty($this->profesorNombre)) {
            return collect();
        }

        $termino = $this->run_profesor;
        $runsPeriodo = \App\Helpers\SemesterHelper::getRunsDocentesDelPeriodo();

        // Solo sugerir docentes que imparten clases en el semestre actual
        return Profesor::where(function ($q) use ($termino) {
                $q->where('run_profesor', 'like', '%' . $termino . '%')
                  ->orWhere('name', 'like', '%' . $termino . '%');
            })
            ->orderBy('name')
            ->limit($runsPeriodo === null ? 5 : 200)
            ->get()
            ->when($runsPeriodo !== null, fn($c) => $c->filter(
                fn($p) => isset($runsPeriodo[\App\Helpers\SemesterHelper::normalizarRun($p->run_profesor)])
            ))
            ->take(5)
            ->values();
    }

    public function selectProfesor($run, $nombre)
    {
        $this->run_profesor = $run;
        $this->profesorNombre = $nombre;
    }

    public function updatedRunProfesor()
    {
        // Si el usuario empieza a escribir de nuevo, limpiar el nombre seleccionado
        if (!empty($this->profesorNombre)) {
            $profesor = Profesor::where('run_profesor', $this->run_profesor)->first();
            if (!$profesor || $profesor->name !== $this->profesorNombre) {
                $this->profesorNombre = '';
            }
        }
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortField = $field;
            $this->sortDirection = 'asc';
        }
    }

    public function openCreateModal()
    {
        $this->reset(['run_profesor', 'profesorNombre', 'fecha_inicio', 'fecha_fin', 'motivo', 'observaciones', 'genera_recuperacion', 'editMode', 'licenciaId']);
        $this->genera_recuperacion = true;
        $this->showModal = true;
    }

    public function openEditModal($id)
    {
        $licencia = LicenciaProfesor::findOrFail($id);
        $this->licenciaId = $id;
        $this->run_profesor = $licencia->run_profesor;
        $this->profesorNombre = $licencia->profesor->name ?? '';
        $this->fecha_inicio = $licencia->fecha_inicio->format('Y-m-d');
        $this->fecha_fin = $licencia->fecha_fin->format('Y-m-d');
        $this->motivo = $licencia->motivo;
        $this->observaciones = $licencia->observaciones;
        $this->genera_recuperacion = $licencia->genera_recuperacion;
        $this->editMode = true;
        $this->showModal = true;
    }

    public function closeModal()
    {
        $this->showModal = false;
        $this->reset(['run_profesor', 'profesorNombre', 'fecha_inicio', 'fecha_fin', 'motivo', 'observaciones', 'genera_recuperacion', 'editMode', 'licenciaId']);
    }

    public function save()
    {
        $this->validate();

        $data = [
            'run_profesor' => $this->run_profesor,
            'fecha_inicio' => $this->fecha_inicio,
            'fecha_fin' => $this->fecha_fin,
            'motivo' => $this->motivo,
            'observaciones' => $this->observaciones,
            'genera_recuperacion' => $this->genera_recuperacion,
        ];

        $service = new LicenciaRecuperacionService();

        if ($this->editMode) {
            $licencia = LicenciaProfesor::findOrFail($this->licenciaId);
            $licencia->update($data);
            
            // Regenerar clases a recuperar si está habilitado
            if ($licencia->genera_recuperacion) {
                $clasesGeneradas = $service->regenerarClasesARecuperar($licencia);
                session()->flash('message', "Licencia actualizada. {$clasesGeneradas} clases programadas para recuperar.");
            } else {
                // Si se desactiva, eliminar las clases pendientes
                $service->eliminarClasesARecuperar($licencia);
                session()->flash('message', 'Licencia actualizada exitosamente.');
            }
        } else {
            $data['created_by'] = Auth::user()->run;
            $data['estado'] = 'activa';
            $licencia = LicenciaProfesor::create($data);
            
            // El Observer se encargará de generar las clases automáticamente
            session()->flash('message', 'Licencia creada exitosamente.');
        }

        $this->closeModal();
    }

    public function cambiarEstado($id, $nuevoEstado)
    {
        $licencia = LicenciaProfesor::findOrFail($id);
        $licencia->update(['estado' => $nuevoEstado]);
        session()->flash('message', 'Estado de licencia actualizado.');
    }

    public function delete($id)
    {
        $licencia = LicenciaProfesor::findOrFail($id);
        
        // El cascade en la base de datos eliminará automáticamente las recuperaciones asociadas
        $licencia->delete();
        
        session()->flash('message', 'Licencia y clases asociadas eliminadas exitosamente.');
    }

    public function render()
    {
        $query = LicenciaProfesor::with(['profesor', 'creador', 'recuperaciones'])
            ->when($this->search, function ($q) {
                $rawSearch = trim($this->search);
                $cleanRun = preg_replace('/[^0-9kK]/', '', $rawSearch);
                $words = array_values(array_filter(explode(' ', $rawSearch), fn($w) => mb_strlen(trim($w)) > 0));

                $q->where(function ($subQ) use ($words, $cleanRun) {
                    if (!empty($words)) {
                        $subQ->whereHas('profesor', function ($query) use ($words) {
                            foreach ($words as $word) {
                                $query->where('name', 'like', '%' . $word . '%');
                            }
                        });
                    }
                    if (!empty($cleanRun)) {
                        $subQ->orWhereHas('profesor', function ($query) use ($cleanRun) {
                            $query->where('run_profesor', 'like', '%' . $cleanRun . '%');
                        });
                    }
                });
            })
            ->when($this->estado, function ($q) {
                $q->where('estado', $this->estado);
            })
            ->orderBy($this->sortField, $this->sortDirection);

        $licencias = $query->paginate(15);
        $runsPeriodo = \App\Helpers\SemesterHelper::getRunsDocentesDelPeriodo();
        $profesores = Profesor::orderBy('name')->get();
        if ($runsPeriodo !== null) {
            // Solo docentes que imparten clases en el semestre actual
            $profesores = $profesores->filter(
                fn($p) => isset($runsPeriodo[\App\Helpers\SemesterHelper::normalizarRun($p->run_profesor)])
            )->values();
        }

        return view('livewire.licencias-profesores-table', [
            'licencias' => $licencias,
            'profesores' => $profesores,
        ]);
    }
}
